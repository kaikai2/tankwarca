// BoundaryLine.cpp: implementation of the CBoundaryLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Ziyoo2DTriaMesh.h"
#include "BoundaryLine.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBoundaryLine::CBoundaryLine()
{
    PtNum = 0;
}

CBoundaryLine::~CBoundaryLine()
{
    CBoundaryPoint *pPt;
    for( int i = 0; i < PtNum; i++)
    {
        pPt = PtArray[i];
        delete pPt;
    }

    PtArray.RemoveAll();
}
void CBoundaryLine::DrawLine(BOOL IsLoop)
{
    int i, size;
    GLushort  pattern;
    int factor;

    factor =1;
    pattern = 0x5555;
    size = HPtArray.GetSize();

    glColor4d(0, 0, 0, 0.5);
    glLineWidth(2.0);

    if( size > 0 ) 
    {
        glEnable(GL_LINE_STIPPLE);
        glLineStipple(factor, pattern);
    }
    else
    {
        glDisable(GL_LINE_STIPPLE);
    }

    if( IsLoop )
        glBegin(GL_LINE_LOOP);
    else
        glBegin(GL_LINE_STRIP);
    for( i = 0; i < PtNum; i++ )
    {
        glVertex2d(PtArray[i]->x,PtArray[i]->y);
    }
    glEnd();
    
    glColor4d(1.0, 0, 0, 0.5);

    glDisable(GL_LINE_STIPPLE);
    glBegin(GL_LINE_LOOP);
    for( i = 0; i < size; i++ )
    {
        glVertex2d(HPtArray[i]->x,HPtArray[i]->y);
    }
    glEnd();

    glLineWidth(1.0);
}

void CBoundaryLine::AddPoint(double x, double y)
{
    CBoundaryPoint *pPt;

    pPt = new CBoundaryPoint;
    
    pPt->x = x;
    pPt->y = y;

    PtArray.Add(pPt);

    PtNum++;
}

extern"C"__declspec(dllimport) void triangle_plane_surf(double pt[][3],
                                                        int nbdynode[],
                                                        int *nb,
                                                        int nbln[],
                                                        double bnu[],
                                                        double bnv[],
                                                        int elements[][3],
                                                        int *elemnum,
                                                        int *error,
                                                        char* ErrorStr);

BOOL CBoundaryLine::TriangulateMesh(int Elements[][3], 
                                    int *ElemNum)
{
    double  temp_bdy_node[2000][3];
    int     nbdynode[2000];
    int     BdyNum, BdyLine[100];
    double  BdyParamU[2000],BdyParamV[2000];
    int     RetError;
    char    ErrorStr[256];

    int i;


    if( PtNum <= 2 ) return TRUE;

    RetError = 0;
    BdyNum = 1;
    BdyLine[0] = PtNum;

    for( i = 0; i < PtNum; i++)
    {
        temp_bdy_node[i][0] = PtArray[i]->x;
        temp_bdy_node[i][1] = PtArray[i]->y;
        temp_bdy_node[i][2] = 0;
        nbdynode[i] = i+1;

        BdyParamU[i] = 0;
        BdyParamV[i] = 0;
    }

    triangle_plane_surf(temp_bdy_node, 
                        nbdynode, 
                        &BdyNum, 
                        BdyLine, 
                        BdyParamU,
                        BdyParamV,
                        Elements,
                        ElemNum,
                        &RetError,
                        ErrorStr);

    return TRUE;
}

void CBoundaryLine::GetMaxMin(double *xmax,
                              double *xmin,
                              double *ymax,
                              double *ymin)
{
    int i;

    *xmin = *xmax = PtArray[0]->x;
    *ymin = *ymax = PtArray[0]->y;   
    for( i = 1; i < PtNum; i++)
    {
        if( PtArray[i]->x > *xmax ) 
            *xmax = PtArray[i]->x;
        
        if( PtArray[i]->x < *xmin )
            *xmin = PtArray[i]->x;

        if( PtArray[i]->y > *ymax ) 
            *ymax = PtArray[i]->y;
        
        if( PtArray[i]->y < *ymin )
            *ymin = PtArray[i]->y;
    }
}

BOOL CBoundaryLine::TriangulatePlaneViaBdyAndInterPts()
{
    return TRUE;
}

void CBoundaryLine::AddMeshElemTria(int Node1, int Node2, int Node3)
{
    CMeshElement *pElem;

    pElem = new CMeshElement;

    pElem->NodeIndex[0] = Node1;
    pElem->NodeIndex[1] = Node2;
    pElem->NodeIndex[2] = Node3;
    pElem->NodeNum = 3;

    ElemArray.Add(pElem);
}

void CBoundaryLine::DrawElement()
{
    CMeshElement *pElem;
    int i, size;

    size = ElemArray.GetSize();
    for( i = 0; i < size; i++ )
    {
        pElem = ElemArray[i];
        if( pElem->NodeNum == 3 )
        {
            glBegin(GL_LINE_LOOP);
            glVertex2d(PtArray[pElem->NodeIndex[0]]->x,PtArray[pElem->NodeIndex[0]]->y);
            glVertex2d(PtArray[pElem->NodeIndex[1]]->x,PtArray[pElem->NodeIndex[1]]->y);
            glVertex2d(PtArray[pElem->NodeIndex[2]]->x,PtArray[pElem->NodeIndex[2]]->y);
            glEnd();
        }
    }
}

// BoundaryLine.h: interface for the CBoundaryLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOUNDARYLINE_H__2C1962FB_1EAB_4442_A24E_2F51578CA951__INCLUDED_)
#define AFX_BOUNDARYLINE_H__2C1962FB_1EAB_4442_A24E_2F51578CA951__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BoundaryPoint.h"
#include "MeshElement.h"
#include <afxtempl.h>

class CBoundaryLine  
{
public:
	void DrawElement();
	void AddMeshElemTria(int Node1, int Node2, int Node3);
    BOOL TriangulatePlaneViaBdyAndInterPts();
	void GetMaxMin(double *xmax,
                   double *xmin,
                   double *ymax,
                   double *ymin);
	BOOL TriangulateMesh(int Elements[][3], int *ElemNum);
	CBoundaryLine();
	virtual ~CBoundaryLine();

	void ResetHPtArray();
	void AddPoint(double x, double y);
	void DrawLine(BOOL IsLoop);

	CArray<CBoundaryPoint*, CBoundaryPoint*> PtArray;
    int PtNum;

    CArray<CMeshElement*, CMeshElement*> ElemArray;
    int ElemNum;

	CArray<CBoundaryPoint*, CBoundaryPoint*> HPtArray;

};

#endif // !defined(AFX_BOUNDARYLINE_H__2C1962FB_1EAB_4442_A24E_2F51578CA951__INCLUDED_)

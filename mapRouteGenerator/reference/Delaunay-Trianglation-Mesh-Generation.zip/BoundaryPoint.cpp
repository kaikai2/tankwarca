// BoundaryPoint.cpp: implementation of the CBoundaryPoint class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Ziyoo2DTriaMesh.h"
#include "BoundaryPoint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBoundaryPoint::CBoundaryPoint()
{

}

CBoundaryPoint::~CBoundaryPoint()
{

}

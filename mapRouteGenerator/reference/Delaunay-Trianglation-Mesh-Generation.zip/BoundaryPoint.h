// BoundaryPoint.h: interface for the CBoundaryPoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOUNDARYPOINT_H__CA86F684_B8B6_4585_AA95_D589FECAD5AE__INCLUDED_)
#define AFX_BOUNDARYPOINT_H__CA86F684_B8B6_4585_AA95_D589FECAD5AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CBoundaryPoint  
{
public:
	CBoundaryPoint();
	virtual ~CBoundaryPoint();

    double x, y;
};

#endif // !defined(AFX_BOUNDARYPOINT_H__CA86F684_B8B6_4585_AA95_D589FECAD5AE__INCLUDED_)

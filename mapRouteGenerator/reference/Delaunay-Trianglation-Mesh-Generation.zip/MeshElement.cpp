// MeshElement.cpp: implementation of the CMeshElement class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Ziyoo2DTriaMesh.h"
#include "MeshElement.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMeshElement::CMeshElement()
{
    NodeNum = 0;
}

CMeshElement::~CMeshElement()
{

}

// MeshElement.h: interface for the CMeshElement class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESHELEMENT_H__CFD85955_9B20_479D_93A1_995FD191723D__INCLUDED_)
#define AFX_MESHELEMENT_H__CFD85955_9B20_479D_93A1_995FD191723D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMeshElement  
{
public:
	CMeshElement();
	virtual ~CMeshElement();
    
    int NodeNum;
    int NodeIndex[4];
};

#endif // !defined(AFX_MESHELEMENT_H__CFD85955_9B20_479D_93A1_995FD191723D__INCLUDED_)

// Ziyoo2DTriaMeshDoc.cpp : implementation of the CZiyoo2DTriaMeshDoc class
//

#include "stdafx.h"
#include "Ziyoo2DTriaMesh.h"
#include "Ziyoo2DTriaMeshDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshDoc

IMPLEMENT_DYNCREATE(CZiyoo2DTriaMeshDoc, CDocument)

BEGIN_MESSAGE_MAP(CZiyoo2DTriaMeshDoc, CDocument)
	//{{AFX_MSG_MAP(CZiyoo2DTriaMeshDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshDoc construction/destruction

CZiyoo2DTriaMeshDoc::CZiyoo2DTriaMeshDoc()
{
    PtNum = 0;
    LnNum = 0;
}

CZiyoo2DTriaMeshDoc::~CZiyoo2DTriaMeshDoc()
{
}

BOOL CZiyoo2DTriaMeshDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshDoc serialization

void CZiyoo2DTriaMeshDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshDoc diagnostics

#ifdef _DEBUG
void CZiyoo2DTriaMeshDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CZiyoo2DTriaMeshDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshDoc commands
void CZiyoo2DTriaMeshDoc::AddPt(double x, double y)
{
    PtList[PtNum][0] = x;
    PtList[PtNum][1] = y;
    
    PtNum++;
}

void CZiyoo2DTriaMeshDoc::DrawLines()
{
    for( int i = 0; i < LnNum; i++)
    {
        LnArray[i]->DrawLine(TRUE);
    }
}

void CZiyoo2DTriaMeshDoc::AddLine()
{
    int i;
    CBoundaryLine* pLn;

    pLn = new CBoundaryLine;

    LnArray.Add(pLn);
    LnNum++;
    
    for( i = 0; i < PtNum; i++)
    {
        pLn->AddPoint(PtList[i][0], PtList[i][1]);
    }

    PtNum = 0;
}


void CZiyoo2DTriaMeshDoc::DrawElement()
{
    int i;

    for( i = 0; i < LnNum; i++ )
    {
        LnArray[i]->DrawElement();
    }
}

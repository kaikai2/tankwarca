// Ziyoo2DTriaMeshDoc.h : interface of the CZiyoo2DTriaMeshDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZIYOO2DTRIAMESHDOC_H__F42D8D10_D4FC_4839_AB77_2EFC79558E32__INCLUDED_)
#define AFX_ZIYOO2DTRIAMESHDOC_H__F42D8D10_D4FC_4839_AB77_2EFC79558E32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BoundaryLine.h"
#include <afxtempl.h>

class CZiyoo2DTriaMeshDoc : public CDocument
{
protected: // create from serialization only
	CZiyoo2DTriaMeshDoc();
	DECLARE_DYNCREATE(CZiyoo2DTriaMeshDoc)

// Attributes
public:
	CArray<CBoundaryLine*, CBoundaryLine*> LnArray;

    int LnNum;


    int PtNum;
    double PtList[1000][2];


// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZiyoo2DTriaMeshDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void DrawElement();
    virtual ~CZiyoo2DTriaMeshDoc();

	void AddLine();
	void DrawLines();
	void AddPt(double x, double z);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CZiyoo2DTriaMeshDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZIYOO2DTRIAMESHDOC_H__F42D8D10_D4FC_4839_AB77_2EFC79558E32__INCLUDED_)

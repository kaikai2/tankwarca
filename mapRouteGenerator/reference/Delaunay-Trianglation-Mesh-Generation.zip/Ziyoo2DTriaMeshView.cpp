// Ziyoo2DTriaMeshView.cpp : implementation of the CZiyoo2DTriaMeshView class
//

#include "stdafx.h"
#include "Ziyoo2DTriaMesh.h"

#include "Ziyoo2DTriaMeshDoc.h"
#include "Ziyoo2DTriaMeshView.h"
#include "MeshElement.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView

IMPLEMENT_DYNCREATE(CZiyoo2DTriaMeshView, CView)

BEGIN_MESSAGE_MAP(CZiyoo2DTriaMeshView, CView)
	//{{AFX_MSG_MAP(CZiyoo2DTriaMeshView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_TRIANGULATE, OnTriangulate)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView construction/destruction

CZiyoo2DTriaMeshView::CZiyoo2DTriaMeshView()
{
	ViewportOffset_x = 0.0;
	ViewportOffset_y = 0.0;
	ViewportOffset_z = 0.0;

	x_angle = 0.0 ;
	y_angle = 0.0 ;
	z_angle = 0.0 ;

	left = - 200;
	right = 200;
	bottom = - 200;
	top =  200;

    
	scalefactor = 1 ;
	window_scale = 1 ;

	for( int i = 0 ; i < 16; i++ )
	{
		ModelMatrix[i] = 0;
		ProjeMatrix[i] = 0;
		ModelMatrix_coord[i] = 0;
		ProjeMatrix_coord[i] = 0;
		if ( i % 5 == 0 )
		{
			ModelMatrix[i] = 1;
			ProjeMatrix[i] = 1;
			ModelMatrix_coord[i] = 1;
			ProjeMatrix_coord[i] = 1;
		}
	}

}

CZiyoo2DTriaMeshView::~CZiyoo2DTriaMeshView()
{
}

BOOL CZiyoo2DTriaMeshView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView drawing

void CZiyoo2DTriaMeshView::OnDraw(CDC* pDC)
{
	CZiyoo2DTriaMeshDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
    DrawScreen();
}

void CZiyoo2DTriaMeshView::DrawScreen()
{
	CZiyoo2DTriaMeshDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
    int i;

	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    pDoc->DrawLines();
    pDoc->DrawElement();

    glColor3i(0, 0, 0);
    glBegin(GL_LINE_STRIP);
    for( i = 0; i < pDoc->PtNum; i++ )
    {
        glVertex2d(pDoc->PtList[i][0],pDoc->PtList[i][1]);
    }
    glEnd();

	glFinish();
	SwapBuffers(m_pDC->GetSafeHdc());
}

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView printing

BOOL CZiyoo2DTriaMeshView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CZiyoo2DTriaMeshView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CZiyoo2DTriaMeshView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView diagnostics

#ifdef _DEBUG
void CZiyoo2DTriaMeshView::AssertValid() const
{
	CView::AssertValid();
}

void CZiyoo2DTriaMeshView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CZiyoo2DTriaMeshDoc* CZiyoo2DTriaMeshView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CZiyoo2DTriaMeshDoc)));
	return (CZiyoo2DTriaMeshDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZiyoo2DTriaMeshView message handlers
void CZiyoo2DTriaMeshView::SettingLight()
{
}


BOOL CZiyoo2DTriaMeshView::bSetupPixelFormat()
{
    static PIXELFORMATDESCRIPTOR pfd = 
	{
        sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
        1,                              // version number
        PFD_DRAW_TO_WINDOW |            // support window
          PFD_SUPPORT_OPENGL |          // support OpenGL
          PFD_DOUBLEBUFFER,             // double buffered
        PFD_TYPE_RGBA,                  // RGBA type
        24,                             // 24-bit color depth
        0, 0, 0, 0, 0, 0,               // color bits ignored
        0,                              // no alpha buffer
        0,                              // shift bit ignored
        0,                              // no accumulation buffer
        0, 0, 0, 0,                     // accum bits ignored
        32,                             // 32-bit z-buffer
        8,                              // 8-bit stencil buffer
        0,                              // no auxiliary buffer
        PFD_MAIN_PLANE,                 // main layer
        0,                              // reserved
        0, 0, 0                         // layer masks ignored
    };
    int pixelformat;

    if ( (pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
    {
        MessageBox("ChoosePixelFormat failed");
        return FALSE;
    }

    if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
    {
        MessageBox("SetPixelFormat failed");
        return FALSE;
    }

    return TRUE;
}

int CZiyoo2DTriaMeshView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    OpenGLInit();	
	
	return 0;
}


void CZiyoo2DTriaMeshView::OpenGLInit()
{
    PIXELFORMATDESCRIPTOR pfd;
    int         n;

    m_pDC = new CClientDC(this);

    ASSERT(m_pDC != NULL);

    if (!bSetupPixelFormat())
        return;

    n = ::GetPixelFormat(m_pDC->GetSafeHdc());
    ::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

    m_hglrc = wglCreateContext(m_pDC->GetSafeHdc());
    wglMakeCurrent(m_pDC->GetSafeHdc(), m_hglrc);

    GetClientRect(&m_oldRect);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_NORMALIZE);
    glDepthFunc(GL_LESS);
	glShadeModel(GL_SMOOTH);

    SettingLight();

	wglUseFontBitmaps( m_pDC->GetSafeHdc(), 0, 256, 1000 ); 

	
	if (m_oldRect.bottom)
		Aspect = (double)m_oldRect.right/m_oldRect.bottom;
	else	// don't divide by zero, not that we should ever run into that...
		Aspect = 1.0;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(left,right,bottom,top,-1,1);
	glTranslated(ViewportOffset_x,ViewportOffset_y,ViewportOffset_z);
	glMatrixMode(GL_MODELVIEW);
}


BOOL CZiyoo2DTriaMeshView::OnEraseBkgnd(CDC* pDC) 
{

	return CView::OnEraseBkgnd(pDC);
}

void CZiyoo2DTriaMeshView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
    if(cy > 0)
    {
		GLdouble xy = (double)cx/cy ;

		if ( xy < (right-left)/(top-bottom) )
		{
			viewport_left = cx/2-(int)((right-left)/(top-bottom)*cy/2.0) ;
			viewport_bottom = 0 ;
			viewport_width = (int)((right-left)/(top-bottom)*cy) ;
			viewport_heigth = cy ;
			scalefactor = ( top - bottom ) / cy ;
		}
		else
		{
			viewport_left = 0 ;
			viewport_bottom = cy/2-(int)((top-bottom)/(right-left)*cx/2.0) ;
			viewport_width = cx ;
			viewport_heigth = (int)((top-bottom)/(right-left)*cx) ;
			scalefactor = ( right - left ) / cx ;
		}

		glViewport( viewport_left, viewport_bottom, viewport_width, viewport_heigth );

		m_oldRect.right  = cx;
		m_oldRect.bottom = cy;

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(left,right,bottom,top,-1, 1);

//        glMultMatrixd( ProjeMatrix );
		
		glMatrixMode(GL_MODELVIEW);
    }
	
}

void CZiyoo2DTriaMeshView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CZiyoo2DTriaMeshDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    int winx, winy, winz;
    double x, y, z;

    winx = point.x;
    winy = m_oldRect.bottom - point.y;
    winz = 0;

	glGetDoublev( GL_MODELVIEW_MATRIX  , ModelMatrix ) ;
	glGetDoublev( GL_PROJECTION_MATRIX , ProjeMatrix ) ;
	glGetIntegerv( GL_VIEWPORT, Viewport ) ;

    gluUnProject(winx, 
                 winy, 
                 winz, 
                 ModelMatrix, 
                 ProjeMatrix,
                 Viewport,
                 &x,
                 &y,
                 &z);
	
    pDoc->AddPt(x, y);

    DrawScreen();
	
	CView::OnLButtonUp(nFlags, point);
}

void CZiyoo2DTriaMeshView::OnRButtonUp(UINT nFlags, CPoint point) 
{
	CZiyoo2DTriaMeshDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    pDoc->AddLine();

    DrawScreen();
	
	CView::OnRButtonUp(nFlags, point);
}

void CZiyoo2DTriaMeshView::OnTriangulate() 
{
    int i, j;
    int     Elements[2000][3], ElemNum;

	CZiyoo2DTriaMeshDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    for( i = 0; i < pDoc->LnNum; i++ )
    {
        pDoc->LnArray[i]->TriangulateMesh(Elements, &ElemNum);
        for( j = 0; j < ElemNum; j++ )
        {
            pDoc->LnArray[i]->AddMeshElemTria(Elements[j][0]-1,
                                              Elements[j][1]-1,
                                              Elements[j][2]-1);
        }

    }
    DrawScreen();
}

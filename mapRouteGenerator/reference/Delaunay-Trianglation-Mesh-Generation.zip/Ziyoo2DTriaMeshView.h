// Ziyoo2DTriaMeshView.h : interface of the CZiyoo2DTriaMeshView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZIYOO2DTRIAMESHVIEW_H__10521CC1_CC55_4523_9591_614CA4BA928A__INCLUDED_)
#define AFX_ZIYOO2DTRIAMESHVIEW_H__10521CC1_CC55_4523_9591_614CA4BA928A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CZiyoo2DTriaMeshView : public CView
{
protected: // create from serialization only
	CZiyoo2DTriaMeshView();
	DECLARE_DYNCREATE(CZiyoo2DTriaMeshView)

// Attributes
public:
	CZiyoo2DTriaMeshDoc* GetDocument();

	double  scalefactor ;
	double window_scale ;
	GLint  viewport_left   ;
	GLint  viewport_bottom ;
	GLsizei viewport_width ;
	GLsizei viewport_heigth ;
	double ViewportOffset_x ; 
	double ViewportOffset_y ;
	double ViewportOffset_z ;
	double x_angle, y_angle, z_angle ;
	double	 left, right, bottom, top;
	CClientDC	*m_pDC;
	HGLRC m_hglrc;
	CRect m_oldRect ;
	double Aspect ; 
	UINT m_zoomOperation ;

    double ModelMatrix[16];
	double ProjeMatrix[16];
    int Viewport[4];

	double ModelMatrix_coord[16];
	double ProjeMatrix_coord[16];
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZiyoo2DTriaMeshView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CZiyoo2DTriaMeshView();

	void DrawScreen();
	void OpenGLInit();
	void SettingLight();
	BOOL bSetupPixelFormat();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CZiyoo2DTriaMeshView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnTriangulate();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Ziyoo2DTriaMeshView.cpp
inline CZiyoo2DTriaMeshDoc* CZiyoo2DTriaMeshView::GetDocument()
   { return (CZiyoo2DTriaMeshDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZIYOO2DTRIAMESHVIEW_H__10521CC1_CC55_4523_9591_614CA4BA928A__INCLUDED_)

//-----------------------------------------------------------------------
//
// LayoutTools
//
// Hilfsfunktionen fuer GridBagLayouts etc.
//
// PK 1996-09-03
//
//-----------------------------------------------------------------------

import java.awt.*;

public class LayoutTools {
	public static void gridBagConstrain(Container container, 
				Component component, int grid_x, int grid_y,
				int grid_width, int grid_height, int fill, int anchor,
				double weight_x, double weight_y, int top, int left,
				int bottom, int right) {
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = grid_x;
		c.gridy = grid_y;
		c.gridwidth = grid_width;
		c.gridheight = grid_height;
		c.fill = fill;
		c.anchor = anchor;
		c.weightx = weight_x;
		c.weighty = weight_y;
		if(top+bottom+left+right > 0)
			c.insets = new Insets(top, left, bottom, right);

		((GridBagLayout) container.getLayout()).setConstraints(component, c);
		container.add(component);
	}
}


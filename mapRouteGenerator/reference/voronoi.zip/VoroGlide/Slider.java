/*
 * @(#)Slider.java    0.90 11/15/95 Adam Doppelt
 */
import java.awt.*;

/**
 * A Slider is a widget that varies between a minimum and a maximum
 * value. The user can drag a "thumb" to change the current value. As
 * the slider is dragged, Motion() is called. When the slider is
 * released, Release() is called. Override these two methods to give
 * the slider behavior.
 *
 * @version 0.90 15 Nov 1995
 * @author <A HREF="http://www.cs.brown.edu/people/amd/">Adam Doppelt</A> */
//
// Modified to meet our needs Sep 1996 Peter Koellner 
//

public class Slider extends Canvas {
	private final static int THUMB_SIZE = 14;
	private final static int BUFFER = 2;

	private final static int BUTTON_WIDTH = 12;
	private final static int BUTTON_SIZE = BUTTON_WIDTH + 4;
	private final static int TEXT_HEIGHT = 18;
	private final static int TEXT_BUFFER = 3;

	private final static int DEFAULT_WIDTH = 100 + 2 * BUTTON_SIZE;
	private final static int DEFAULT_HEIGHT = 15;

	private final static int MIN_WIDTH = 2 * (THUMB_SIZE + BUFFER + 1 + BUTTON_SIZE);
	private final static int MIN_HEIGHT = 2 * (BUFFER + 1);

	private final static int DEFAULT_MIN = 1;
	private final static int DEFAULT_MAX = 100;    
    
	int min, max, value, pixel;
	int pixelMin, pixelMax;
	int bar_height;

	int min_width, min_height;

	Color backgroundColor, thumbColor, barColor, slashColor, textColor;
	Font font;
    
/**
 * Constructs a slider.
 * @param container The container for this slider.
 */
	public Slider () {
		min = DEFAULT_MIN;
		max = DEFAULT_MAX;
		resize(DEFAULT_WIDTH, DEFAULT_HEIGHT + TEXT_HEIGHT);
		min_width = DEFAULT_WIDTH;
		min_height = DEFAULT_HEIGHT + TEXT_HEIGHT;

		font = new Font("TimesRoman", Font.PLAIN, 12);
		backgroundColor = Color.lightGray;
		thumbColor = Color.lightGray;
		barColor = Color.lightGray.darker();
		slashColor = Color.black;
		textColor = Color.black;
		SetBarHeight(size().height);
		SetValue(1);
	}

/**
 * This method is called when the "thumb" of the slider is dragged by
 * the user. Must be overridden to give the slider some behavior.
 *   */
	public void Motion() {
	}

/**
 * This method is called when the "thumb" of the slider is released
 * after being dragged. Must be overridden to give the slider some
 * behavior.
 *   */

	public void Release() {
	}
    
/**
 * Sets the maximum value for the slider.
 * @param num The new maximum.
 */
	public void SetMaximum (int num) {
		max = num;
		if (max < min) {
			int t = min;
			min = max;
			max = t;
		}

		SetValue(value);
	}
    
/**
 * Sets the minimum value for the slider.
 * @param num The new minimum.
 */
	public void SetMinimum (int num) {
		min = num;
		if (max < min) {
			int t = min;
			min = max;
			max = t;
		}

		SetValue(value);
	}

/**
 * Sets the current value for the slider. The thumb will move to
 * reflect the new setting.
 * @param num The new setting for the slider.
 *   */

	public void SetValue (int num) {
		value = num;

		if(value < min)
			value = min;
		else if(value > max)
			value = max;

		if(value != min)
			pixel = (int) (Math.round(Math.abs((double) (value - min) /
														  (double) (max - min)) *
											  (double) (pixelMax - pixelMin)) + pixelMin);
		else
			pixel = pixelMin;

		repaint();
	}

/**
 * Sets the height of the slider. This is the height of the entire
 * slider canvas, including space reserved for displaying the
 * current value.
 * @param num The new height.
 *   */

	public void SetHeight(int num) {
		if (num < MIN_HEIGHT + TEXT_HEIGHT)
			num = MIN_HEIGHT + TEXT_HEIGHT;
		min_height = num;
		resize(size().width, num);
		repaint();
	}
    
/**
 * Sets the width of the slider. This is the width of the actual
 * slider box.
 * @param num The new width.
 *   */

	public void SetWidth(int num) {
		if (num < MIN_WIDTH)
			num = MIN_WIDTH;
		min_width = num;
		resize(num + 2 * BUTTON_SIZE, size().height);
		repaint();	
	}
    
/**
 * Sets the Height of the sliderbar. 
 * @param num The new height.
 *   */

	public void SetBarHeight(int num) {
		if (num > size().height - TEXT_HEIGHT)
			num = size().height - TEXT_HEIGHT;
		bar_height = num;
		repaint();	
	}
    
/**
 * Returns the current value for the slider.
 * @return The current value for the slider.
 */

	public int GetValue() {
		return value;
	}

/**
 * Sets the background color for the slider. The "background" is the
 * area outside of the bar.
 * @param color The new background color.
 */

	public void SetBackgroundColor(Color color) {
		backgroundColor = color;
		repaint();
	}

/**
 * Sets the color for the slider's thumb. The "thumb" is the box that
 * the user can slide back and forth.
 * @param color The new thumb color.
 */

	public void SetThumbColor(Color color) {
		thumbColor = color;
		repaint();
	}

/**
 * Sets the color for the slider's bar. The "bar" is the rectangle
 * that the thumb slides around in.
 * @param color The new bar color.
 */

	public void SetBarColor (Color color) {
		barColor = color;
		repaint();
	}

/**
 * Sets the slash color for the slider. The "slash" is the little
 * vertical line on the thumb.
 * @param color The new slash color.
 */

	public void SetSlashColor(Color color) {
		slashColor = color;
		repaint();
	}

/**
 * Sets the color for the slider`s text.
 * @param color The new text color.
 */

	public void SetTextColor(Color color) {
		textColor = color;
		repaint();
	}

/**
 * Sets the font for the slider`s text.
 * @param font The new font.
 */
	public void SetFont(Font font) {
		this.font = font;
		repaint();
	}
    
/**
 * An internal method used to handle repaint events.
 */

	public void paint(Graphics g) {
		int width = size().width;	
		int height = size().height;

		g.setColor(backgroundColor);
		g.fillRect(0, 0, width, height);

		int bar_offset = (height - TEXT_HEIGHT - bar_height) >> 1;

		g.setColor(barColor);
		g.fill3DRect(BUTTON_SIZE, TEXT_HEIGHT + bar_offset, width - 2 * BUTTON_SIZE, bar_height, false);

		g.setColor(thumbColor);
		g.fill3DRect(BUTTON_SIZE + pixel - THUMB_SIZE, TEXT_HEIGHT + BUFFER,
		     THUMB_SIZE * 2 + 1, height - 2 * BUFFER - TEXT_HEIGHT,
		     true);

		g.fill3DRect(0, TEXT_HEIGHT,
		     BUTTON_WIDTH, height - TEXT_HEIGHT,
		     true);

		g.fill3DRect(width - BUTTON_WIDTH, TEXT_HEIGHT,
		     BUTTON_WIDTH, height - TEXT_HEIGHT,
		     true);

		g.setColor(slashColor);
		g.drawLine(BUTTON_SIZE + pixel, TEXT_HEIGHT + BUFFER + 1, BUTTON_SIZE + pixel, height - 2 * BUFFER);

		g.setColor(textColor);
		g.setFont(font);

		String str = String.valueOf(value);
		g.drawString(str, BUTTON_SIZE + pixel -
						 (int)(getFontMetrics(font).stringWidth(str) / 2),
						 TEXT_HEIGHT - TEXT_BUFFER);
	}

	void HandleMouse(int x) {
		double percent;
		int width = size().width - 2 * BUTTON_SIZE;
		pixel = Math.max(x - BUTTON_SIZE, pixelMin);
		pixel = Math.min(pixel, pixelMax);

		if(pixel != pixelMin)
			percent = (((double) pixel - pixelMin) /
						  (pixelMax - pixelMin));
		else
			percent = 0;

		value = (int) (Math.round(percent * (double) (max - min))) + min;

		paint(getGraphics());
	}
    
/**
 * An internal method used to handle mouse down events.
 */

	public boolean mouseDown (Event e, int x, int y) {
		HandleMouse(x);
		Motion();
		return true;
	}

/**
 * An internal method used to handle mouse drag events.
 */
	public boolean mouseDrag (Event e, int x, int y) {
		HandleMouse(x);
		Motion();	
		return true;
	}

/**
 * An internal method used to handle mouse up events.
 */

	public boolean mouseUp (Event e, int x, int y) {
		HandleMouse(x);
		Release();
		return true;
	}

/**
 * An internal method used to handle resizing.
 */

	public void reshape(int x, int y, int width, int height) {
		super.reshape(x, y, width, height);
		pixelMin = THUMB_SIZE + BUFFER;
		pixelMax = width - 2 * BUTTON_SIZE - THUMB_SIZE - BUFFER - 1;
		if(value != min)
		pixel = (int) (Math.round(Math.abs((double) (value - min) /
													  (double) (max - min)) *
										  (double) (pixelMax - pixelMin)) +
							pixelMin);
		else
			pixel = pixelMin;
	}

	public Dimension minimumSize() {
		Dimension d = new Dimension(min_width, min_height);
//	System.out.println("Min size: " + d);
		return(d);
	}

	public Dimension preferredSize() {
		Dimension d = new Dimension(min_width, min_height);
//	System.out.println("Pref size: " + d);
		return(d);
	}
}


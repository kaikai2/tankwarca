//
// SpeedSlider.java
//
// PK 1996-09-24
//

import java.awt.*;

public class SpeedSlider extends Slider {
	VoronoiApplet app;

	public SpeedSlider(VoronoiApplet va, int w, int h, int min, int max, int v) {
		SetWidth(w);
		SetHeight(h);
		SetMinimum(min);
		SetMaximum(max);
		SetValue(v);
		SetBarHeight(5);
		SetBarColor(Color.gray);
		app = va;
	}

	public void Motion() {
		app.evRec.recordEvent(ajEvent.STEP_SPEED, GetValue());
		app.stepper.set_time(GetValue());
	}

	public void Release() {
				app.evRec.recordEvent(ajEvent.STEP_SPEED, GetValue());
		app.stepper.set_time(GetValue());
	}
}

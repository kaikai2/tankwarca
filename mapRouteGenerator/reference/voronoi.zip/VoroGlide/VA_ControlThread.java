/*
 * Copyright (c) 1995, 1996 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
import java.io.*;
import java.net.*;
import java.util.*;

class VA_ControlThread extends Thread {
	public DatagramSocket socket;
	public byte[] buffer;

	VA_Server server;

	public String toString() {
		return "VA_ControlThread: socket = " + socket;
	}

	VA_ControlThread(DatagramSocket socket, VA_Server server) throws IOException {
		super("VA_Server");

		this.socket = socket;
		this.server = server;
		buffer = new byte[1024];
	}

	public void run() {
		while (socket != null) {
			try {
				DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

				//Read data.
				socket.receive(packet);

				String str = new String(buffer, 0, 0, packet.getLength());

				System.out.println("Received: <" + str + ">");

				String key = packet.getAddress().toString();

				System.out.println("key: " + key);

				//Pass it on.

				String msg = str;

				System.out.println("Message: " + msg);
				if (msg != null) {
					if(msg.compareTo("TERM") == 0) {
						System.out.println("Terminating.");
						System.runFinalization();
						System.exit(0);
						System.out.println("???");
					} else {
						server.toVoronoi(key, msg);
					}
				}
			} catch (EOFException e) { //No more data on this socket...
				cleanup();
				return;
			} catch (NullPointerException e) { //Socket doesnt exist...
				cleanup();
				return;
			} catch (IOException e) { //Read problem..
				cleanup();
				return;
			} catch (Exception e) { //Unknown exception. Complain and quit.
				System.err.println("Exception on receive Packet:");
				e.printStackTrace();
				cleanup();
				return;
			}
		}
	}

	protected void finalize() throws Throwable {
		cleanup();
		super.finalize();
	}

	void cleanup() {
		try {
			if (socket != null) {
				socket.close();
				socket = null;
			}
		} catch (Exception e) {} //Ignore errors.
	}
}

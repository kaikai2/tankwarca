public class VA_Message {
	public static boolean check_length(String str) {
//		System.out.println("Received: <" + str + ">");

		int tokenIndex = str.indexOf('|');

		String subString = str.substring(0, tokenIndex);

		int length = Integer.parseInt(subString);

		return(str.length() == length + tokenIndex);
	}

	public static String get_message(String str) {
		int tokenIndex = str.indexOf('|');

		String subString = str.substring(tokenIndex + 1, str.length());

		return(subString);
	}

	public static String compose_message(String str) {
		String ret = (str.length() + 1) + "|" + str;
		return(ret);
	}

	public static String compose_cmd(String cmd, String arg) {
		String ret = cmd + "|" + arg;
		return(ret);
	}

	public static String get_cmd(String str) {
		int tokenIndex = str.indexOf('|');

		String subString;

		if(tokenIndex > 0)
			subString = str.substring(0, tokenIndex);
		else
			subString = str;

		return(subString);
	}

	public static String get_arg(String str) {
		int tokenIndex = str.indexOf('|');

		String subString = str.substring(tokenIndex + 1, str.length());

		return(subString);
	}

}

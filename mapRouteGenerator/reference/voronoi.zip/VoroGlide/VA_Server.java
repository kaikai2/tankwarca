/*
 * Copyright (c) 1995, 1996 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
//-----------------------------------------------------------------------
//
//  Modified 1996-08-22 PK
//
//-----------------------------------------------------------------------

import java.net.*;
import java.io.*;
import java.util.*;

public class VA_Server {
	int VoronoiPort;
	static int DEFAULT_VPORT = 12987;
	int ControlPort;
	static int DEFAULT_CPORT = 12989;
	static int MAX_SERVER_THREADS = 10;
	ServerSocket serverVSocket = null;
	DatagramSocket dWSocket = null;

	byte[] buffer;

	Hashtable ts_thread = new Hashtable();
	int next_thread = 0;
	int num_connected = 0;

	VA_ControlThread tc_thread;

	public VA_Server(int vport, int cport) {
		VoronoiPort = vport;
		ControlPort = cport;
	}

	public static void main(String[] args) {
		int i;
		int vport = DEFAULT_VPORT;
		int cport = DEFAULT_CPORT;

		for(i = 0; i < args.length - 1; i++) {
			if(args[i].compareTo("-vport") == 0) {
				try {
					vport = Integer.parseInt(args[i+1]);
				} catch(NumberFormatException ex) {
					System.err.println("Wrong number format for Voronoi port.");
					return;
				}
			} else if(args[i].compareTo("-cport") == 0) {
				try {
					cport = Integer.parseInt(args[i+1]);
				} catch(NumberFormatException ex) {
					System.err.println("Wrong number format for Control port.");
					return;
				}
			}
		}
		new VA_Server(vport, cport).start();
	}

	public void start() {
		try {
			serverVSocket = new ServerSocket(VoronoiPort);
		} catch (IOException e) {
			System.err.println("Server could not create server socket for VoronoiApplet.");
			return;
		}

		try {
			dWSocket = new DatagramSocket(ControlPort);
		} catch (IOException e) {
			System.err.println("Server could not create datagram socket for Whiteboard.");
			return;
		}

		tc_thread = connectToWB(dWSocket); //DatagramSocket fuer alle Verb.

		while (true) {
			//Connect to VoronoiApplet

			if(num_connected < MAX_SERVER_THREADS) {
				VA_ServerThread vast = connectToVA(serverVSocket);
				if(vast != null) {
					String key = insert_thread(vast);
					num_connected++;

					String msg = VA_Message.compose_cmd("REGISTER", key);

					toVoronoi(key, msg);
				}
			} else {
				try {
					Thread.sleep(1000);
				} catch(InterruptedException intex) {
				}
			}
			check();
		}
	}

	protected void finalize() throws Throwable {
		cleanup();
		try {
			serverVSocket.close();
			dWSocket.close();
		} catch(IOException ex) {}
		serverVSocket = null;
		super.finalize();
	}

	protected VA_ServerThread connectToVA(ServerSocket serverRSocket) {
		DataOutputStream os = null;
		Socket rendezvousSocket = null;
		VA_ServerThread tst = null;

		System.out.println("Wait for " + serverRSocket);

		//Listen for client connection on the rendezvous socket.
		try {
			rendezvousSocket = serverRSocket.accept();
		} catch (IOException e) {
			System.err.println("Accept failed.");
			e.printStackTrace();
			return null;
		}

		System.out.println("Connected to VoronoiApplet at " + rendezvousSocket);

		//Create a thread to handle this connection.
		try {
			tst = new VA_ServerThread(rendezvousSocket, this);
			tst.start();
		} catch (Exception e) {
			System.err.println("Couldn't create VA_ServerThread:");
			e.printStackTrace();
			return null;
		}

		return tst;
	}

	protected synchronized VA_ControlThread connectToWB(DatagramSocket dsock) {
		VA_ControlThread tst;

		//Create a thread to handle this connection.
		try {
			tst = new VA_ControlThread(dsock, this);
			tst.start();
		} catch (Exception e) {
			System.err.println("Couldn't create VA_ControlThread:");
			e.printStackTrace();
			return null;
		}

		return tst;
	}

	synchronized void check() {
		Enumeration enum = ts_thread.elements();

		while(enum.hasMoreElements()) {
			VA_ServerThread tst = (VA_ServerThread) enum.nextElement();
			if(tst.is == null || tst.os == null || tst.socket == null)
				remove_thread(tst.key);
		}
	}

	synchronized void cleanup() {
		Enumeration enum = ts_thread.elements();

		while(enum.hasMoreElements()) {
			VA_ServerThread tst = (VA_ServerThread) enum.nextElement();
			cleanup(tst);
		}

		ts_thread.clear();
	}

	synchronized void cleanup(VA_ServerThread tst) {
		System.out.println("cleanup thread " + tst);
		if (tst != null) tst.cleanup();
	}

	public void toVoronoi(String key, String str) {
		VA_ServerThread thr = get_thread(key);

		if(thr == null) {
			System.err.println("No VA_ServerThread for " + key);
			return;
		}

		String msg = VA_Message.compose_message(str);

		synchronized(thr) {
			try {
				writeToStream(msg, thr.os);
			} catch(NullPointerException nullex) {
				System.err.println("No VA_ServerThread #" + key);
			}
		}
	}

	void writeToStream(String string, DataOutputStream stream) {
		System.out.println("Write to stream: " + string);
		try { 
			stream.writeUTF(string);
			stream.flush();
		} catch (IOException e) {
			System.err.println("VA_Server failed to forward string:");
			e.printStackTrace();
			return;
		} catch (NullPointerException e) {
			System.err.println("VA_Server can't forward string "
									 + "since output stream is null.");
			return;
		}
	}

	public synchronized String insert_thread(VA_ServerThread thr) {
		thr.key = thr.socket.getInetAddress().toString();
		ts_thread.put(thr.key, thr);
		return thr.key;
	}

	public synchronized VA_ServerThread get_thread(String key) {
		return((VA_ServerThread) ts_thread.get(key));
	}

	public synchronized void remove_thread(String key) {
		System.out.println("Remove Server Thread #" + key);
		ts_thread.remove(key);
		
		System.out.println("Active Threads:");

		Enumeration en = ts_thread.elements();
		while(en.hasMoreElements()) {
			System.out.println("Server Thread: " + (VA_ServerThread) en.nextElement());
		}
		num_connected--;
	}
}

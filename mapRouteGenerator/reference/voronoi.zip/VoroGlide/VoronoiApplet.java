//-------------------------------------------------------------------------
//
// VoronoiApplet
//
// Steuerungsteil f�r Voronoi-Diagramme und Delaunay-Triangulationen
//
//-------------------------------------------------------------------------

import java.applet.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class VoronoiApplet extends Applet implements ajUpdate {
  final static int SHOW_VORO = 1;
  final static int SHOW_DEL = 2;
  final static int SHOW_CONV = 4;

  boolean hasPrint = false;
  ajCanvas canvas;
  ajExtendDelaunay delau;
  ajRecorder evRec;
  ajStep stepper;
  AudioClip clip;

  ajFrame frame;
  int f_w, f_h;

  boolean stepMode = false; // Einzelschrittmodus
  boolean stepping = false; // Flag: Einzelschrittanimation l�uft

  Button sf;

  ajSingleStepPanel stepPanel;
  ajRecorderPanel recPanel;

  Frame recFrame, stepFrame;

  int viewtype;

  Event dragEvent = null;

  ajPoint pick, step_point;

  boolean stopped = false;

  String helpURL;

  //
  // init() wird ausgefuehrt, wenn die Webseite mit dem Applet geladen wird.
  // Die Funktion wird nicht ausgefuehrt, wenn die Seite erneut sichtbar gemacht
  // wird !!!
  //

  public void init() {
    String fws = getParameter("FrameWidth");
    String fhs = getParameter("FrameHeight");
    String panels = getParameter("Panels");
    String rc = getParameter("RemoteControl");
    String showframe = getParameter("FrameShow");
    String appcolor = getParameter("Color");
    String unBuf = getParameter("unBuf");

    String showinfo = getParameter("Info");

    helpURL = getParameter("HelpURL");

	if(helpURL==null)
		helpURL = "VA_UserManual.html";

   String jvers = System.getProperty("java.version");

	hasPrint = !jvers.startsWith("1.0");

    if(showinfo != null && showinfo.compareTo("true") == 0) {
      String jvend = System.getProperty("java.vendor");
      String jvurl = System.getProperty("java.vendor.url");
      String jclvr = System.getProperty("java.class.version");
      String osnam = System.getProperty("os.name");
      String osarc = System.getProperty("os.arch");
      String osver = System.getProperty("os.version");

      System.err.println("Java Environment Info");
      System.err.println("Java");
      System.err.println("     Version:        " + jvers);
      System.err.println("     Vendor:         " + jvend);
      System.err.println("     Vendor URL:     " + jvurl);
      System.err.println("     API Version:    " + jclvr);
      System.err.println("OS");
      System.err.println("   Name:             " + osnam);
      System.err.println("   Architecture:     " + osarc);
      System.err.println("   Version:     " + osver);
	 }

    try {
      f_w = new Integer(fws).intValue();
	 } catch(NumberFormatException nex) {
      f_w = 800;
	 }

    try {
      f_h = new Integer(fhs).intValue();
	 } catch(NumberFormatException nex) {
      f_h = 800;
	 }

    Dimension scr = Toolkit.getDefaultToolkit().getScreenSize();

    if (f_w > scr.width)
      f_w = (int) ((float) scr.width * 0.8);
    if (f_h > scr.height)
      f_h = (int) ((float) scr.height * 0.8);

    frame=new ajFrame(this, "VoroGlide 2.2", f_w, f_h);

    evRec = new ajRecorder(this);

    canvas = new ajCanvas();
    canvas.animate.sleepTime = 30;
    canvas.resize(size());
    setLayout(new BorderLayout());
    frame.add("Center", canvas);
    canvas.unsetOffscreen();

    delau = new ajExtendDelaunay( canvas );

    recFrame = new Frame("Recorder");
    stepFrame = new Frame("Step Mode");

    ajButtonImages img = new ajButtonImages(this);

    stepPanel = new ajSingleStepPanel(this, img);
    recPanel = new ajRecorderPanel(this, img);

    stepFrame.add("Center",stepPanel);
    stepFrame.pack();

    recFrame.add("Center",recPanel);
    recFrame.pack();

    recPanel.save.disable();

    stepper = new ajStep(stepPanel, canvas);
    stepper.set_time(1000);

    canvas.add(delau);
    canvas.updateInterface = this;

    if(rc != null && rc.compareTo("true") == 0) {
      socketListenerThread slt = new socketListenerThread(this);
      slt.start();
	 }

    frame.pack();

    frame.resize(f_w, f_h);

    if(showframe != null && showframe.compareTo("true") == 0) {
      frame.show();

      if(panels != null && panels.compareTo("all") == 0) {
        recFrame.show();
        stepFrame.show();
      } else if(panels != null && panels.compareTo("simple") == 0) {
        recFrame.hide();
        stepFrame.hide();
      } else {
        recFrame.hide();
        stepFrame.hide();
      }
    }

    if(appcolor != null) {
      Color c = new Color(Integer.parseInt(appcolor, 16));
      if(c != null)
        this.setBackground(c);
    }

    setLayout(new BorderLayout(5, 5));

    String btext = getParameter("ButtonText");

    if(btext != null) {
      sf = new Button(btext);
	 } else {
      sf = new Button("Show Voronoi Frame");
	 }

    sf.setFont(new Font("Helvetica", Font.BOLD, 14));

    add("Center", sf);
    show();

    setFrameViewtype(SHOW_VORO);

    frame.unBuf.setState(false);
    unBufferedDisplay(frame.unBuf.getState());

    frame.thin.setState(false);
    thinLines(frame.thin.getState());
    
  } // Ende init

  //
  // destroy() soll sonstige Resourcen freigeben.
  //

  public void destroy() {
    recFrame.hide();
    stepFrame.hide();
    frame.hide();
    recFrame.dispose();
    stepFrame.dispose();
    frame.dispose();
  }

  public String getHelpURL() {
    return helpURL;
  }

  public void ajUpdate( Graphics g ) {
    if ( dragEvent == null || pick == null ) {
      canvas.paint(g);  // Kein Drag-Event, also alles neu malen
      return;
    }

    pick.move( dragEvent.x,dragEvent.y ); // Punkt bewegen

    evRec.recordEvent(ajEvent.MOVE_POINT, pick);

    delau.insertTemp( pick );
    canvas.paintTempLayers();
    dragEvent = null;
  }


//
// ajUpdate handle<Event> Methoden
// !!! VORSICHT !!!
// NICHT MIT keyDown() etc. VERWECHSELN!
// Diese Funktionen dienen nur der Behandlung spezieller Canvas-Ereignisse!
//

// Punkt ausw�hlen oder einf�gen

  public boolean handleMouseDown( Event evt, int x, int y ) {
    if ( pick != null || stepping )
      return true; // nichts tun, wenn noch bewegt oder ge"steppt" wird.

    pick = canvas.pickPoint(x,y);

    if ( (evt.modifiers & Event.META_MASK) != 0) { // rechte Maustaste

      if (pick == null) return true;               // nichts zu entfernen

      evRec.recordEvent(ajEvent.RM_POINT, pick);   // Punkt pick entfernen

      canvas.remove(pick);
      delau.recompute();
      canvas.repaint();
      pick = null;
      return true;
    }

    if ( pick != null ) {                   // Punkt gibts schon, bewegen
      evRec.recordEvent( ajEvent.SET_POINT, pick);

      canvas.remove(pick);
      delau.recompute();
      delau.insertTemp(pick);
      canvas.repaint();
      return true;
    }

    ajPoint p = new ajPoint(x,y);           // neuer Punkt, einf�gen:

    evRec.recordEvent( ajEvent.SET_POINT, p);

    canvas.add(p);
    if(stepMode && delau.showDelaunayState()) {  // im Einzelschrittmodus
      stepPanel.ez_led.switch_on();
      stepper.reset();
      stepping = true;
      step_point = p;
      delau.insertTemp( p,stepper );
      stepPanel.stepPlay.switch_on();
      stepper.begin();
    } else {
      delau.insertPoint(p);                      // bzw. direkt
      canvas.repaint();
    }
    return true;
  }


// Punkt bewegen

  public boolean handleMouseDrag( Event evt, int x, int y ) {
    if (pick==null || stepping)
      return true;

    // im Fenster halten
    if ( x < 0 )
      evt.x = -1;
    else if ( x >= canvas.width )
      evt.x = canvas.width;

    if ( y < 0 )
      evt.y = -1;
    else if ( y >= canvas.height )
      evt.y = canvas.height;

    // nicht auf einen anderen legen
    if ( canvas.pickPoint( evt.x, evt.y ) != null )
      return true;

    dragEvent = evt;
    canvas.repaint();
    return true;
  }


// Punkt loslassen

  public boolean handleMouseUp( Event evt, int x, int y ) {
    if (stepping)
      return true;

    evRec.recordEvent(ajEvent.FINISH_MOVE_POINT, evt.x, evt.y);

    if ( pick == null )
      return true; // nichts loszulassen

    canvas.cleanTempLayers();
    pick.color = ajElement.pointColor;
    canvas.add(pick);  // pick hat die Koordinaten des letzten zul�ssigen Drags, nicht x,y.
    delau.insertPoint(pick);
    delau.endMotion();
    canvas.repaint();
    pick=null;
    dragEvent = null;
    return true;
  }

  public boolean handleMouseEnter(Event e, int x, int y) {
    if(stepping)
      return true;

    return false;
  }

  public boolean handleMouseExit(Event e, int x, int y) {
    if(stepping)
      return true;

    return false;
  }

  public boolean handleMouseMove(Event e, int x, int y) {
    if(stepping)
      return true;

    return false;
  }

  public boolean handleKeyDown(Event e, int k) {
    if(stepping)
      return true;

    return false;
  }

  public boolean handleKeyUp(Event e, int k) {
    if(stepping)
      return true;

    return(false);
  }

//
// GUI Elemente - Ereignisauswertung
//

  public boolean keyDown(Event e, int k) {
    if(stepping)
      return true;

    if(k == 's') {
      stepFrame.show();
		return true;
	 }
    if(k == 'r') {
      recFrame.show();
      return true;
	 }
    if(k == 'a') {
      recFrame.show();
      stepFrame.show();
      return true;
	 }

    if(k == 'S') {
      stepFrame.hide();
		return true;
	 }
    if(k == 'R') {
      recFrame.hide();
      return true;
	 }
    if(k == 'A') {
      recFrame.hide();
      stepFrame.hide();
      return true;
	 }

    return super.keyDown(e, k);
  }

  public boolean action(Event evt, Object obj) {
    if(evt.target == evRec) {
      ajEvent aje = (ajEvent) evt.arg;
      Event nev = null;

      switch(aje.eventType) {
        case ajEvent.SET_POINT:
          nev = new Event(canvas, evt.when, Event.MOUSE_DOWN,
                     aje.arg1, aje.arg2, 0, 0);
          canvas.postEvent(nev);
          return(true);
        case ajEvent.MOVE_POINT:
          nev = new Event(canvas, evt.when, Event.MOUSE_DRAG,
                     aje.arg1, aje.arg2, 0, 0);
          canvas.postEvent(nev);
          return(true);
        case ajEvent.FINISH_MOVE_POINT:
          nev = new Event(canvas, evt.when, Event.MOUSE_UP,
                     aje.arg1, aje.arg2, 0, 0);
          canvas.postEvent(nev);
          return(true);
        case ajEvent.VIEWTYPE:
          setFrameViewtype(aje.arg1);
          return true;
        case ajEvent.SHOW_REST:
/*          optionPanel.shRest.setState(aje.barg);
			nev = new Event(optionPanel.shRest, evt.when, Event.ACTION_EVENT,
							 aje.arg1, aje.arg2, 0, 0);
			optionPanel.postEvent(nev);
*/			return true;
        case ajEvent.DOUBLE_BUFFER:
         frame.unBuf.setState(aje.barg);
			nev = new Event(frame.unBuf, evt.when, Event.ACTION_EVENT,
							 aje.arg1, aje.arg2, 0, 0);
			frame.postEvent(nev);
			return true;
        case ajEvent.STEP_MODE:
          frame.step.setState(aje.barg);
			nev = new Event(frame.step, evt.when, Event.ACTION_EVENT,
							 aje.arg1, aje.arg2, 0, 0);
			frame.postEvent(nev);
			return true;
        case ajEvent.STEP_SPEED:
          stepPanel.slider.SetValue(aje.arg1);
          evt.target = stepPanel.slider;
          break;
        case ajEvent.STEP:
          return(stepPanel.action(evt, obj));
        case ajEvent.CLEAR:
			nev = new Event(frame.clr, evt.when, Event.ACTION_EVENT,
							 aje.arg1, aje.arg2, 0, 0);
			frame.postEvent(nev);
			return true;
        case ajEvent.RESIZE:
          return(true);
        case ajEvent.RM_POINT:
          nev = new Event(canvas, evt.when, Event.MOUSE_DOWN,
                     aje.arg1, aje.arg2, 0, Event.META_MASK);
          canvas.postEvent(nev);
          return true;
        case ajEvent.END_REC:
          showStatus("Replay finished.");
          recPanel.stop_rec();
//			delau.startTriangle.visitAndPrint();
          return true;
        default:
          return true;
      }
    }
    if(evt.target == stepPanel.ez_ende || evt.target == stepper) {
		end_stepping(evt.target == stepPanel.ez_ende, evt.target == stepPanel.ez_ende);
		return true;
    }

    String panels = getParameter("Panels");

    if(evt.target == sf) {
      frame.show();

      if(panels != null && panels.compareTo("all") == 0) {
        recFrame.show();
        stepFrame.show();
      } else if(panels != null && panels.compareTo("simple") == 0) {
        recFrame.hide();
        stepFrame.hide();
      } else {
        recFrame.hide();
        stepFrame.hide();
      }
		return true;
	 }
    return super.action(evt, obj);
  }

  void do_stop() {
    if(clip != null)
      clip.stop();
    if(stopped) {
      stopped = false;
		evRec.start();
	 }
    evRec.recordEvent(ajEvent.END_REC);
    evRec.stop_recording();
    showStatus("Stopped.");
    end_stepping(false, true);
    if ( pick != null ) {
      canvas.cleanTempLayers();
      pick.color = ajElement.pointColor;
      canvas.add(pick);
      delau.insertPoint(pick);
      delau.endMotion();
      canvas.repaint();
      pick=null;
      dragEvent = null;
	 }
    frame.demo.setState(false);
    evRec.stop_replay();
    recPanel.stop_rec();
  }

  void do_replay() {
    if(stopped) {
      stopped = false;
		evRec.start();
	 }
    evRec.stop_recording();
    evRec.stop_replay();
    if(evRec.hasRecord()) {
      clear_canvas();
      showStatus("Replay");
      recPanel.do_replay();
      evRec.start_replay();
    }
  }

  void do_pause() {
    if(!stopped) {
      evRec.stop();
      stopped = true;
    } else {
      evRec.start();
      stopped = false;
    }
  }

  void do_record() {
    if(stopped) {
      stopped = false;
		evRec.start();
	 }
    evRec.stop_replay();
    showStatus("Recording...");
    String clipname = getParameter("AudioClip");
    if(clipname != null)
    try {
      URL clipurl=new URL(clipname);
      if(clipurl != null) {
        clip = getAudioClip(clipurl);
        clip.play();
	   }
	 } catch(MalformedURLException ux) {
	 } catch(NullPointerException nx) {
	 }
    recPanel.do_record();
    evRec.start_recording();

    recordInitialState(viewtype, frame.unBuf.getState(), false,
                            stepMode, stepPanel.slider.GetValue());

    ajPoint pt = (ajPoint) canvas.drawPoints.anchor;

    while(pt != null) {
      evRec.recordEvent(ajEvent.SET_POINT, pt);
      pt = (ajPoint) pt.getNext();
    }

    recPanel.rec_led.switch_on();
  }

	void setFrameViewtype(int v) {
		if((v & SHOW_VORO) != 0)
			frame.shVor.setState(true);
		else
			frame.shVor.setState(false);
		if((v & SHOW_DEL) != 0)
			frame.shDel.setState(true);
		else
			frame.shDel.setState(false);
		if((v & SHOW_CONV) != 0)
			frame.shConv.setState(true);
		else
			frame.shConv.setState(false);

		setViewtype(frame.shVor.getState(), frame.shDel.getState(),
						frame.shConv.getState());
	}

	void setViewtype(boolean sv, boolean sd, boolean conv) {
		delau.showVoronoi(sv);
		delau.showDelaunay(sd);
		delau.showConvex(conv);

		viewtype = 0;

		if(sv)
			viewtype |= SHOW_VORO;
		if(sd)
			viewtype |= SHOW_DEL;
		if(conv)
			viewtype |= SHOW_CONV;

		canvas.repaint();
		evRec.recordEvent(ajEvent.VIEWTYPE, viewtype);
	}

	void showRest(boolean st) {
		delau.showHidden(st);
		evRec.recordEvent(ajEvent.SHOW_REST, st);
	}

	void unBufferedDisplay(boolean st) {
		if(st) {
			canvas.unsetOffscreen();
		} else {
			// String osn = System.getProperty("os.name");

			// if(osn != null && osn.compareTo("Windows 95") == 0) {
			String buf = getParameter("unBuf");

			if(buf != null && buf.compareTo("true") == 0) {
				System.err.println("Buffered Display not possible");
				canvas.unsetOffscreen();
			} else {
            	     		canvas.setOffscreen();
			}
		}
		evRec.recordEvent(ajEvent.DOUBLE_BUFFER, st);
	}

	void thinLines(boolean st) {
		ajSegment.SetThinLines(st);
		ajPoint.SetSmallPoints(st);
                canvas.repaint();
	}

  void clear_canvas() {
    evRec.recordEvent(ajEvent.CLEAR);
    end_stepping(false, true);
    delau = new ajExtendDelaunay( canvas );
    canvas = delau.canvas;
    setFrameViewtype(viewtype);
    unBufferedDisplay(frame.unBuf.getState());
    thinLines(frame.thin.getState());
    showRest(false);
    canvas.add(delau);
    canvas.repaint();
  }

	public void recordInitialState(int viewtype, boolean dbuf, boolean shrest, boolean stepM, int stepSp) {
		evRec.recordEvent(ajEvent.CLEAR);
		evRec.recordEvent(ajEvent.VIEWTYPE, viewtype);
		evRec.recordEvent(ajEvent.DOUBLE_BUFFER, dbuf);
		evRec.recordEvent(ajEvent.SHOW_REST, shrest);
		evRec.recordEvent(ajEvent.STEP_MODE, stepM);
		evRec.recordEvent(ajEvent.STEP_SPEED, stepSp);
	}

	public void end_stepping(boolean rec, boolean stopstep) {
		if(stepping) {
			stepping = false;
			if(rec)
				evRec.recordEvent(ajEvent.STEP, ajSingleStepPanel.SM_QUIT);
			stepPanel.ez_led.switch_off();
			stepPanel.stepPlay.switch_off();
			if(stopstep)
				stepper.stop_replay();
			canvas.cleanTempLayers();
			delau.insertPoint(step_point);
			step_point = null;
			canvas.repaint();
		}
	}
}

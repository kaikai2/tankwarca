//---------------------------------------------------------------------------
//
// ajAnimation.java
//
// Animations-Interface
//
// Klassen, die animiert werden sollen, implementieren dieses
// Interface.
//
// PK 7.8.1996
//
//---------------------------------------------------------------------------

import java.util.Date;

public interface ajAnimation {
  public void do_it(long time);
}

//---------------------------------------------------------------------------
//
// ajAnimator.java
//
// Animations-Basisklasse
//
// PK 7.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Component;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

public class ajAnimator implements Runnable {
  protected Thread animatorThread = null;
  protected long zeroTime;
  protected Component host;

  public int sleepTime;

  public Vector animations;

  public ajAnimator(Component h) {
    this(h, 200);
  }

  public ajAnimator(Component h, int tm) {
    sleepTime = tm;
    host = h;
    animations = new Vector();
  }

  public void start() {
    Date date = new Date();
    zeroTime = date.getTime();

    if(animatorThread == null) {
      animatorThread = new Thread(this);
      animatorThread.start();
    }
  }

  public void stop() {
    if(animatorThread != null && animatorThread.isAlive())
      animatorThread.stop();
    animatorThread = null;
  }

  public void run() {
    while(true) {
      Date date = new Date();

      if(animations.size() > 0) {
        Enumeration enu = animations.elements();
        while(enu.hasMoreElements()) {
          ((ajAnimation) enu.nextElement()).do_it(date.getTime() - zeroTime);
        }

//        host.repaint();
		}

      try {
        Thread.sleep(sleepTime);
      } catch(InterruptedException e) {};
    }
  }

  public synchronized void add(ajAnimation an) {
    animations.addElement(an);
  }

  public synchronized void remove(ajAnimation an) {
    animations.removeElement(an);
  }
}

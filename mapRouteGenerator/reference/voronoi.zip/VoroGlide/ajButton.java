//---------------------------------------------------------------------------
//
// ajButton
//
// Simulation einer Drucktaste
//
// PK 1996-09-30
//
//---------------------------------------------------------------------------

import java.awt.*;
import java.awt.image.*;
import java.lang.*;
import java.util.*;

public class ajButton extends Canvas implements ajAnimation, ImageObserver {
	public static final int PUSH=0;
	public static final int TOGGLE=1;

	int width;
	int height;
	int type;

	public int state = 0;
	public int save_state = 0;
	long last_sw;
	public long duration = 1000;
	public Color basecolor = Color.black;

	Image img_on, img_off, img_dis;

	public ajButton(int t, Image i_off, Image i_on) {
		img_on = i_on;
		img_off = i_off;
		type = t;

		width = img_on.getWidth(this) + 4;
		height = img_on.getHeight(this) + 4;

		last_sw = 0;
		state = 0;

		GrayFilter gf = new GrayFilter();
		ImageProducer prod = new FilteredImageSource(img_off.getSource(), gf);
		img_dis = createImage(prod);
	}

	public void switch_on() {
		state = 3;
		repaint();
	}

	public void switch_off() {
		state = 0;
		repaint();
	}

	public void blinking() {
		state = 1;
	}

	public void paint(Graphics g) {
		g.setColor(Color.darkGray);
		g.drawRect(0,0, width-1, height-1);
		g.setColor(Color.gray);

		switch(state) {
		case -1:
			g.drawImage(img_dis, 2,2, this);
			break;
		case 0:
		case 1:
			g.drawImage(img_off, 2,2, this);
			break;
		case 2:
		case 3:
			g.drawImage(img_on, 2,2, this);
			break;
		}
	}

	public void do_it(long t) {
		if(t - last_sw > duration) {
			last_sw = t;

			switch(state) {
				case 1:
					state = 2;
					break;
				case 2:
					state = 1;
					break;
				default:
					break;
			}
			repaint();
		}
	}

	public Dimension minimumSize() {
		return(new Dimension(width, height));
	}

	public Dimension preferredSize() {
		return minimumSize();
	}

	public boolean mouseDown(Event evt, int x, int y) {
		if(type == TOGGLE) {
			if(state == 0)
				state = 3;
			else if(state == 3)
				state = 0;
		} else
			state = 3;
		repaint();
		Toolkit.getDefaultToolkit().sync();

		Event ev = new Event(this, evt.when, Event.ACTION_EVENT, x, y, evt.key, evt.modifiers, "Image");
		postEvent(ev);

		return true;
	}

	public boolean mouseUp(Event evt, int x, int y) {
		if(type == TOGGLE)
			return true;
		state = 0;
		repaint();
		Toolkit.getDefaultToolkit().sync();
		return true;
	}

	public boolean imageUpdate(Image i, int infoflags, int x, int y, int w, int h) {
		if((infoflags & ImageObserver.WIDTH) != 0) {
			width = w + 4;
			resize(width, height);
			invalidate();
			if(getParent() != null)
				getParent().layout();
			repaint();
		} if((infoflags & ImageObserver.HEIGHT) != 0) {
			height = h + 4;
			resize(width, height);
			invalidate();
			if(getParent() != null)
				getParent().layout();
			repaint();
		}
		repaint();
		return true;
	}

	public void enable() {
		super.enable();
		state = save_state;
		repaint();
	}

	public void disable() {
		if(state != -1) {
			save_state = state;
			state = -1;
			repaint();
			super.disable();
		}
	}
};

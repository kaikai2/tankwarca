//----------------------------------------------------------------------------------------------------------
//
// ajButtonImages
//
// Alle Images, die in den Panels gebraucht werden
//
// PK 1996-10-21
//
//----------------------------------------------------------------------------------------------------------

import java.applet.*;
import java.awt.*;
import java.net.*;

public class ajButtonImages {
	public Image stopOffImg;
	public Image stopOnImg;

	public Image pauseOffImg;
	public Image pauseOnImg;

	public Image anfangOffImg;
	public Image anfangOnImg;

	public Image stepBackOffImg;
	public Image stepBackOnImg;

	public Image playOffImg;
	public Image playOnImg;

	public Image recordOffImg;
	public Image recordOnImg;

	public Image stepOffImg;
	public Image stepOnImg;

	public Image endeOffImg;
	public Image endeOnImg;

	public Image loadOffImg;
	public Image loadOnImg;

	public Image saveOffImg;
	public Image saveOnImg;

	public ajButtonImages(Applet app) {
		URL docbase = app.getCodeBase();
		stopOffImg = app.getImage(docbase, "Stop_Off.gif");
		stopOnImg = app.getImage(docbase, "Stop_On.gif");

		pauseOffImg = app.getImage(docbase, "Pause_Off.gif");
		pauseOnImg = app.getImage(docbase, "Pause_On.gif");

		anfangOffImg = app.getImage(docbase, "Anfang_Off.gif");
		anfangOnImg = app.getImage(docbase, "Anfang_On.gif");

		stepBackOffImg = app.getImage(docbase, "StepBack_Off.gif");
		stepBackOnImg = app.getImage(docbase, "StepBack_On.gif");

		playOffImg = app.getImage(docbase, "Play_Off.gif");
		playOnImg = app.getImage(docbase, "Play_On.gif");

		recordOffImg = app.getImage(docbase, "Record_Off.gif");
		recordOnImg = app.getImage(docbase, "Record_On.gif");

		stepOffImg = app.getImage(docbase, "Step_Off.gif");
		stepOnImg = app.getImage(docbase, "Step_On.gif");

		endeOffImg = app.getImage(docbase, "Ende_Off.gif");
		endeOnImg = app.getImage(docbase, "Ende_On.gif");

		loadOffImg = app.getImage(docbase, "Load_Off.gif");
		loadOnImg = app.getImage(docbase, "Load_On.gif");

		saveOffImg = app.getImage(docbase, "Save_Off.gif");
		saveOnImg = app.getImage(docbase, "Save_On.gif");
	}
};

//---------------------------------------------------------------------------
//
// ajCanvas.java
//
// Zeichenfl�che mit Eventbearbeitung
//
// PK 7.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.io.*;
import java.net.*;
import java.util.Date;

/** Zeichenf�che f�r "anja" */
public class ajCanvas extends Canvas {
  private boolean realized=false;
  //
  // Konstanten
  //
  public final static int PR_LOW = 0;
  public final static int PR_MED = 1;
  public final static int PR_HIGH = 2;

  //
  // Datenstrukturen
  //

  /** Liste der Layer der Zeichenfl�che */
  public ajList[] drawElements;

  /** ajPoint Elemente werden in dieser Liste verwaltet. */
  public ajList drawPoints = null;

  /** "Double Buffer" Grafik Ausgabe. */
  protected Image offscreen = null;

  /** Breite der Zeichenfl�che */
  protected int imgWidth = 0;
  /** H�he der Zeichenfl�che */
  protected int imgHeight = 0;

  /** Animationsmaschine */
  public ajAnimator animate = new ajAnimator(this);

  //
  // Zum Benutzen des Offscreen-Puffers f�r flickerfreie
  // Anzeige dies auf true setzen:
  //
  /** Double Buffer Schalter */
  public boolean useOffscreen = false;

  private Graphics paintGraphics;

  public int width;
  public int height;

  //
  // Experimentelle Schnittstelle zum Eventrecording
  //

  DataInputStream din = null;
  DataOutputStream dos = null;

  boolean toFile = true;
  boolean fromFile = false;

  //
  // UpdateTrick...
  //

  public ajUpdate updateInterface = null;

  //
  // Konstruktoren
  //

  public ajCanvas() {
    setBackground( ajElement.backgroundColor );
  }

  public ajCanvas( int layers ) {
    drawElements = new ajList[layers];
    setBackground( ajElement.backgroundColor );
    veryClean();  // Arrays initialisieren
  }

  public ajCanvas( int layers, int t ) {
    this( layers );
    animate.sleepTime = t;
  }

  public void createLayers( int layers ) {
    drawElements = new ajList[layers];
    veryClean();
  }

  /** Anpassung des double buffers an Canvas-Abmessungen */

  protected void fixOffscreen() {
    Dimension d = size();

    if(offscreen == null || imgWidth != d.width || imgHeight != d.height) {
		if(realized)
			offscreen = createImage(d.width, d.height);
		imgWidth = d.width;
		imgHeight = d.height;
    }
  }

	public void resize(int w, int h) {
		super.resize(w, h);
//    System.out.println("Resize: " + w + ", " + h);
		width = w;
		height = h;
		if(paintGraphics != null)
			paintGraphics.clipRect(0, 0, width, height);
	}

	public void resize(Dimension d) {
		resize(d.width, d.height);
	}

  public void setOffscreen() {
    useOffscreen = true;

    try {
      fixOffscreen();
    } catch(IllegalArgumentException ex) {
      unsetOffscreen();
      return;
    }

    if(offscreen != null) {
      paintGraphics = offscreen.getGraphics();
    } else paintGraphics = getGraphics();

    if(paintGraphics != null)
      paintGraphics.clipRect(0, 0, width, height);
  }

  public void unsetOffscreen() {
    useOffscreen = false;
    offscreen  = null;

    paintGraphics = getGraphics();
    if(paintGraphics != null)
      paintGraphics.clipRect(0, 0, width, height);
  }

  //
  // Einf�gen/entfernen von graphischen Elementen
  // Die Zeichenebenen werden in der Reihenfolge
  // von 0 bis drawElements.length-1 gezeichnet,
  // danach noch drawPoints dar�ber.
  //

  public void add( ajElement e, int layer ) {
    if ( layer >= 0 && layer < drawElements.length) {
       drawElements[layer].append(e);
       e.priority = layer;
    }
    else System.out.println( "Wrong layer number: "+layer );
  }

  public void add( ajElement e ) {
    add( e,0 );  // Default: layer = 0
  }

  public void add( ajElement el, int layer, Color col ) {
    el.color = col;
    add( el,layer );
  }

  public void add( ajPoint a, ajPoint b, int layer, Color col ) {
    add( new ajSegment(a,b,col), layer );
  }

// Punkte werden in ein eigenes Layer einf�gt
  public void add( ajPoint e ) {
    drawPoints.append(e);
  }

  public void remove(ajElement e) {
    remove(e, e.priority);
  }

  public void remove(ajElement e, int pri) {
    drawElements[pri].remove(e);
    animate.remove(e);
  }

  public void remove(ajPoint e) {
    drawPoints.remove(e); // e ist definitiv nur in einer Liste.
    animate.remove(e);
  }

  // eine Zeichenebene l�schen
  public void cleanLayer(int l) {
    drawElements[l] = new ajList();
  }

  // alle Zeichenebenen l�schen (au�er Nr. 0)
  public void cleanTempLayers() {
    for ( int i = 1; i < drawElements.length; i++ )
      cleanLayer(i);
  }

  // clean l�scht die Punktliste nicht, veryClean l�scht sie auch.
  public void clean() {
    for ( int i = 0; i < drawElements.length; i++ ) 
      cleanLayer(i);  // Einfach �berb�geln, und ab zur GC
  }

  public void veryClean() {
    clean();
    drawPoints = new ajList();
  }


  //
  // Suchen nach Elementen unter der Maus
  //

  public ajElement pick(int x, int y) {
    for(int i = drawElements.length-1; i >= 0; i--) {
      ajElement el = (ajElement) drawElements[i].anchor;
      while(el != null) {
        if(el.match(x, y))
          return el;

        el = (ajElement) el.getNext();
      }
    }
    return(null);
  }

  public ajPoint pickPoint(ajPoint pq) {
    return pickPoint( pq.x, pq.y );
  }

  public ajPoint pickPoint(float fx, float fy) {
    ajPoint pt = (ajPoint) drawPoints.anchor;
    ajPoint ret = null;
    float bestDist = ajPoint.distClose;

    while(pt != null) {
      float ptDist = pt.distance2(fx, fy);
      if (ptDist <= ajPoint.distClose)
        if (ret == null || ptDist < bestDist) {
          ret = pt;
          bestDist = ptDist;
        }
      pt = (ajPoint) pt.getNext();
    }
    return ret;
  }


  //
  // Malen...
  //

  /* Update ohne Seite l�schen */
  public void update(Graphics g) {
    if(updateInterface != null)
      updateInterface.ajUpdate(g);
  };

// L�schen und alles neu malen
  public void paint( Graphics pg ) {
    if(!realized && useOffscreen) {
      realized=true;
      setOffscreen();
    }

    super.paint(paintGraphics); // l�scht die Zeichenfl�che

    for(int i = 0; i < drawElements.length; i++) {
      paintLayer(i);
    }
    paintPoints();
    toScreen();
  }

// Zeichenebene malen
  public void paintLayer( int i ) {
    ajElement el = (ajElement) drawElements[i].anchor;
    while(el != null) {
      if(!el.hidden) el.draw(paintGraphics);
      el = (ajElement) el.getNext();
    }
  }

// alle Zeichenebenen malen (au�er Nr. 0)
  public void paintTempLayers() {
    for ( int i = 1; i < drawElements.length; i++ )
      paintLayer(i);
    toScreen();
  }

// alle Punkte malen
  public void paintPoints() {
    ajPoint pt = (ajPoint) drawPoints.anchor;
    while(pt != null) {
      if(!pt.hidden) pt.draw(paintGraphics);
      pt = (ajPoint) pt.getNext();
    }
  }

// alle Punkte ausgeben (f�r debugging)
  public void printPoints() {
    System.out.println( "printPoints:" );
    ajPoint pt = (ajPoint) drawPoints.anchor;
    while(pt != null) {
      System.out.println( " "+pt );
      pt = (ajPoint) pt.getNext();
    }
  }

  public void toScreen() {
    if(useOffscreen) {
      getGraphics().drawImage(offscreen, 0, 0, this);
    }
  }


// Den ganzen Layer l mit Farbe c einf�rben

  public void changeColorInLayer( int l, Color c ) {
    ajElement el = (ajElement) drawElements[l].anchor;
    while(el != null) {
      el.color = c;
      el = (ajElement) el.getNext();
    }
  }


// Den ganzen Layer l auf Layer m verschieben,
// Layer m wird �berschrieben, Layer l ist danach leer.

  public void moveCleanLayer( int l, int m ) {
    drawElements[m] = drawElements[l];
    cleanLayer(l);
  }


  //
  // Event-Bearbeitung
  //

  public boolean keyDown(Event evt, int key) {
    if(updateInterface != null)
      return updateInterface.handleKeyDown(evt, key);
    return super.keyDown(evt, key);
  }

  public boolean mouseDown(Event evt, int c, int d) {
    if(updateInterface != null)
      return updateInterface.handleMouseDown(evt, c, d);
    return super.mouseDown(evt, c, d);
  }

  public boolean mouseDrag(Event evt, int c, int d) {
    if(updateInterface != null)
      return updateInterface.handleMouseDrag(evt, c, d);
    return super.mouseDrag(evt, c, d);
  }

  public boolean mouseUp(Event evt, int c, int d) {
    if(updateInterface != null)
      return updateInterface.handleMouseUp(evt, c, d);
    return super.mouseUp(evt, c, d);;
  }

  //
  // Animation
  //

  public void start_animation() {
    animate.start();
  }

  public void stop_animation() {
    animate.stop();
  }

  //
  // reshape wird aufggerufen, wenn die Groesse geaendert wird !!!
  //

  public synchronized void reshape(int x, int y, int w, int h) {
    super.reshape(x, y, w, h);
//    System.out.println("Reshape: " + x + ", " + y + ", " + w + ", " + h);
    width = w;
    height = h;
    if(useOffscreen) {
      offscreen = null;
      setOffscreen();
	 } else {
      unsetOffscreen();
	 }
    if(paintGraphics != null)
      paintGraphics.clipRect(0, 0, width, height);
  }

  //
  // minimumSize und preferredSize werden vom LayoutManager 
  // gebraucht. Angeblich jedenfalls...
  //

  public Dimension minimumSize() {
    return(new Dimension(400, 200));
  }

  public Dimension preferredSize() {
    return(new Dimension(width, height));
  }
}

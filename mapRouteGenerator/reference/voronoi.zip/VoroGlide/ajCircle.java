//---------------------------------------------------------------------------
//
// ajCircle.java
//
// Klasse f�r Kreise
//
// LM 7.8.1996
//
//---------------------------------------------------------------------------


import java.awt.*;

public class ajCircle extends ajElement {

  ajPoint c;
  float r;

  public ajCircle(){
    color = circleColor;
  }

  public ajCircle( ajPoint c, float r ) {
    this.c = c;
    this.r = r;
    color = circleColor;
  }


  public ajCircle( ajPoint c, float r, Color col ) {
    this.c = c;
    this.r = r;
    color = col;
  }


  public ajCircle( ajCircle circ, Color col ) {
    this.c = circ.c;
    this.r = circ.r;
    color = col;
  }

  public void draw( Graphics g, Color col ) {
    int i_r = (int) Math.round(Math.sqrt(r));
    int i_x = Math.round(c.x);
    int i_y = Math.round(c.y);

    g.setColor(col);
    g.drawOval(i_x - i_r, i_y - i_r,
    i_r << 1, i_r << 1);
  }

  public String toString() {
    return(new String(" ajCi["+ c.toString() + "|" + r + "|" + (int) Math.round(Math.sqrt(r)) + "]"));
  }


}

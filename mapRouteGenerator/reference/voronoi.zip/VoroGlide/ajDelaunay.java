//---------------------------------------------------------------------------
//
// ajDelaunay.java
//
// Klasse f�r Delaunay-Triangulationen
//
// LM 13.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Graphics;

public class ajDelaunay extends ajElement {

// erster und letzter Punkt im kollinearen Fall
  ajPoint firstP;
  ajPoint lastP;

// bis jetzt sind alle Punkte sind kollinear
  boolean allCollinear;

// erstes, letztes Dreieck (wird nur im kollinearen Fall gebraucht)
  ajTriangle firstT,lastT;

// Startdreieck f�r die point location
  public ajTriangle startTriangle;

// Startdreieck auf dem Rand
  ajTriangle startTriangleHull;

// Gesamtzahl der Punkte
  int nPoints;

// In diesem canvas soll alles angezeigt werden.
  ajCanvas canvas;

// Farben zus�tzlich zu denen in ajElement
  Color color = Color.black;                     // Kanten der Triangulation
  Color VorColor = muchDarker(Color.blue);       // Kanten von VD
  Color HullColor = muchDarker(Color.green);     // konvexe H�lle

// Anzeige der Delaunay-Triangulation (DT)
// bzw. des Voronoi-Diagrammms (VD)
// bzw. der konvexen H�lle gew�nscht
  protected boolean showDel;
  protected boolean showVor;
  protected boolean showHull;


// Konstruktor
//  public ajDelaunay() {
//  }

  public ajDelaunay( ajCanvas c ) {
    canvas = c;
    nPoints = 0;
    allCollinear = true;
  }


// Delaunay-Triangulation ein/ausschalten
   public void showDelaunay( boolean st ) {
      showDel = st;
   }

// Zustand Delaunay-Triangulation ausgeben
	public boolean showDelaunayState() {
		return showDel;
	}

// Voronoi-Diagramm ein/ausschalten
   public void showVoronoi( boolean st ) {
      showVor = st;
   }

// Zustand Voronoi-Diagramm ausgeben
	public boolean showVoronoiState() {
		return showVor;
	}

// Konvexe H�lle ein/ausschalten
   public void showConvex( boolean st ) {
      showHull = st;
   }

// Zustand Konvexe H�lle ausgeben
	public boolean showConvexState() {
		return showHull;
	}


// Punkt p in die DT einf�gen

  public void insertPoint( ajPoint p ) {

    // Dreieckstruktur erweitern, das n�chste mal hier zu suchen anfangen
    ajTriangle t = insertPointSimple(p);

    if ( t == null ) // nichts zu flippen am Anfang
      return;

    ajTriangle tt = t;
    do {
      flip(tt);
      tt = tt.canext;
    } while ( tt != t && !tt.halfplane );
  }


// Punkt p dort einf�gen, wo er lokalisiert wird.
// R�ckgabe ist eines der echten neuen Dreiecke, an dem p beteiligt ist,
// wenn die konvexe H�lle gewachsen ist, dann das erste im Gegenuhrzeigersinn.
// Es wird das Dreieck zur�ckgegeben, bei dem man das Flippen starten soll,
// um die DT in Ordnung zu bringen, bzw. null, wenn man schon fertig ist.

  private ajTriangle insertPointSimple( ajPoint p ) {

    nPoints++;

    if ( !allCollinear ) {
      // es gab schon vorher mindestens 3 Punkte, die nicht kollinear sind.
      ajTriangle t = startTriangle.find(p);
      if (t.halfplane)
        startTriangle = extendOutside(t,p);
      else
        startTriangle = extendInside(t,p);
      return startTriangle;
    }

    if ( nPoints == 1 ) {
      firstP = p;
      return null;
    }

    if ( nPoints == 2 ) {
      startTriangulation( firstP,p );
      return null;
    }

    switch ( p.pointLineTest(firstP,lastP) ) {
      case ajPoint.LEFT:         // Punkte sind jetzt nicht mehr kollinear:
        startTriangle = extendOutside( firstT.abnext,p );
        allCollinear = false;
        break;
      case ajPoint.RIGHT:
        startTriangle = extendOutside( firstT,p );
        allCollinear = false;
        break;
      case ajPoint.ONSEGMENT:    // Punkte sind weiterhin kollinear:
        insertCollinear( p, ajPoint.ONSEGMENT );
        break;
      case ajPoint.INFRONTOFA:
        insertCollinear( p, ajPoint.INFRONTOFA );
        break;
      case ajPoint.BEHINDB:
        insertCollinear( p, ajPoint.BEHINDB );
        break;
    }
    return null;
  }


// Noch einen kollinearen Punkt hinzuf�gen,
// res gibt die Lage bzgl. firstP, lastP an.

  private void insertCollinear( ajPoint p, int res ) {
    ajTriangle t,tp,u;

    switch ( res ) {
      case ajPoint.INFRONTOFA:
        t  = new ajTriangle(firstP,p);
        tp = new ajTriangle(p,firstP);
        t.abnext = tp;
        tp.abnext = t;
        t.bcnext = tp;
        tp.canext = t;
        t.canext = firstT;
        firstT.bcnext = t;
        tp.bcnext = firstT.abnext;
        firstT.abnext.canext = tp;
        firstT = t;
        firstP = p;
        break;
      case ajPoint.BEHINDB:
        t  = new ajTriangle( p,lastP );
        tp = new ajTriangle( lastP,p );
        t.abnext = tp;
        tp.abnext = t;
        t.bcnext = lastT;
        lastT.canext = t;
        t.canext = tp;
        tp.bcnext = t;
        tp.canext = lastT.abnext;
        lastT.abnext.bcnext = tp;
        lastT = t;
        lastP = p;
        break;
      case ajPoint.ONSEGMENT: // lexikografisch einf�gen
        u = firstT;
        while ( p.isGreater(u.a) )
          u = u.canext;
        t  = new ajTriangle(p,u.b);
        tp = new ajTriangle(u.b,p);
        u.b = p;
        u.abnext.a = p;
        t.abnext = tp;
        tp.abnext = t;
        t.bcnext = u.bcnext;
        u.bcnext.canext = t;
        t.canext = u;
        u.bcnext = t;
        tp.canext = u.abnext.canext;
        u.abnext.canext.bcnext = tp;
        tp.bcnext = u.abnext;
        u.abnext.canext = tp;
        if ( firstT == u ) {
          firstT = t;
        }
        break;
    }
  }


// Triangulation anlegen, d. h. erste Dreiecke bauen

  private void startTriangulation( ajPoint p1, ajPoint p2 ) {
    ajPoint ps,pb;
    if ( p1.isLess(p2) ) {
      ps = p1;
      pb = p2;
    } else {
      ps = p2;
      pb = p1;
    }
    firstT = new ajTriangle( pb,ps );
    lastT = firstT;
    ajTriangle t = new ajTriangle( ps,pb );
    firstT.abnext = t;
    t.abnext = firstT;
    firstT.bcnext = t;
    t.canext = firstT;
    firstT.canext = t;
    t.bcnext = firstT;
    firstP = firstT.b;
    lastP = lastT.a;
    startTriangleHull = firstT;
  }


// Triangulation innen erweitern
// Es wird vorausgesetzt, da� t ein Dreieck ist, das p enth�lt,
// t selbst wird als neues Dreieck wiederverwendet und wird zur�ckgegeben.
// Alle neuen Dreiecke bekommen p als ihren Punkt c.

  public ajTriangle extendInside( ajTriangle t, ajPoint p ) {

    ajTriangle h1,h2;
    h1 = treatDegeneracyInside( t,p );
    if ( h1 != null ) return h1;

    h1 = new ajTriangle( t.c,t.a,p );
    h2 = new ajTriangle( t.b,t.c,p );
    t.c = p;
    t.circumcircle();
    h1.abnext = t.canext;
    h1.bcnext = t;
    h1.canext = h2;
    h2.abnext = t.bcnext;
    h2.bcnext = h1;
    h2.canext = t;
    h1.abnext.switchneighbors(t,h1);
    h2.abnext.switchneighbors(t,h2);
    t.bcnext = h2;
    t.canext = h1;
    return t;
  }


// Degenerierte F�lle beim inneren Einf�gen testen und ggfs. behandeln

  public ajTriangle treatDegeneracyInside( ajTriangle t, ajPoint p ) {

    if ( t.abnext.halfplane && p.pointLineTest(t.b,t.a) == ajPoint.ONSEGMENT )
      return extendOutside( t.abnext,p );
    if ( t.bcnext.halfplane && p.pointLineTest(t.c,t.b) == ajPoint.ONSEGMENT )
      return extendOutside( t.bcnext,p );
    if ( t.canext.halfplane && p.pointLineTest(t.a,t.c) == ajPoint.ONSEGMENT )
      return extendOutside( t.canext,p );
    return null;
  }


// Triangulation au�en erweitern.
// Es wird vorausgesetzt, da� t eine Halbebene ist, die p enth�lt.
// Alle neuen echten Dreiecke bekommen p als ihren Punkt c.
// Zur�ck kommt das erste der entstehenden geschlossenen Dreiecke.

  private ajTriangle extendOutside( ajTriangle t, ajPoint p ) {

    if ( p.pointLineTest(t.a,t.b) == ajPoint.ONSEGMENT ) { // degenerate
      ajTriangle dg = new ajTriangle( t.a,t.b,p );
      ajTriangle hp = new ajTriangle( p,t.b );
      t.b = p;
      dg.abnext = t.abnext;
      dg.abnext.switchneighbors(t,dg);
      dg.bcnext = hp;
      hp.abnext = dg;
      dg.canext = t;
      t.abnext = dg;
      hp.bcnext = t.bcnext;
      hp.bcnext.canext = hp;
      hp.canext = t;
      t.bcnext = hp;
      return dg;
    }
    ajTriangle ccT = extendcounterclock( t, p );
    ajTriangle cT = extendclock( t, p );
    ccT.bcnext = cT;
    cT.canext = ccT;
    startTriangleHull = cT;
    return cT.abnext;
  }


// Triangulation au�en erweitern im Gegenuhrzeigersinn.
// Es wird vorausgesetzt, da� t eine Halbebene ist, die p enth�lt.
// Das letzte Dreieck der Reihe (die neuerzeugte Halbebene)
// wird zur�ckgegeben.

  private ajTriangle extendcounterclock( ajTriangle t, ajPoint p ) {

    t.halfplane = false; // schlie�e t mit Punkt p
    t.c = p;
    t.circumcircle();

    ajTriangle tca = t.canext;

    if ( p.pointLineTest(tca.a,tca.b) >= ajPoint.RIGHT ) {
      ajTriangle nT = new ajTriangle( t.a,p );
      nT.abnext = t;
      t.canext = nT;
      nT.canext = tca;
      tca.bcnext = nT;
      return nT;
    }
    return extendcounterclock(tca,p);
  }


// Triangulation au�en erweitern im Uhrzeigersinn.
// Es wird vorausgesetzt, da� t eine Halbebene ist, die p enth�lt.
// Das letzte Dreieck der Reihe (die neuerzeugte Halbebene)
// wird zur�ckgegeben.

  private ajTriangle extendclock( ajTriangle t, ajPoint p ) {

    t.halfplane = false; // schlie�e t mit Punkt p
    t.c = p;
    t.circumcircle();

    ajTriangle tbc = t.bcnext;

    if ( p.pointLineTest(tbc.a,tbc.b) >= ajPoint.RIGHT ) {
      ajTriangle nT=new ajTriangle(p,t.b);
      nT.abnext=t;
      t.bcnext=nT;
      nT.bcnext=tbc;
      tbc.canext=nT;
      return nT;
    }
    return extendclock(tbc,p);
  }


// Macht, falls erforderlich, einen edge flip und rekursiv weiter.
// t.c ist der zuletzt eingef�gte Punkt.
// Bedingung f�r den edge flip ist, da� t.c im Umkreis von t.abnext liegt.

  public void flip( ajTriangle t ) {

    ajTriangle u=t.abnext, v;

    if ( u.halfplane || !u.circumcircle_contains(t.c) ) // kein flip n�tig
      return;

    if ( t.a == u.a ) {
      v = new ajTriangle( u.b,t.b,t.c );
      v.abnext = u.bcnext;
      t.abnext = u.abnext;
    } 
    else if ( t.a == u.b ) {
      v = new ajTriangle( u.c,t.b,t.c );
      v.abnext = u.canext;
      t.abnext = u.bcnext;
    }
    else if ( t.a == u.c ) {
      v = new ajTriangle( u.a,t.b,t.c );
      v.abnext = u.abnext;
      t.abnext = u.canext;
    } 
    else {
      System.out.println( "Error in flip." );
      return;
    }

    v.bcnext=t.bcnext;
    v.abnext.switchneighbors(u,v);
    v.bcnext.switchneighbors(t,v);
    t.bcnext=v;
    v.canext=t;
    t.b = v.a;
    t.abnext.switchneighbors(u,t);
    t.circumcircle();

             // rekursiv weiter.
    flip(t); // Man beachte, da� t.c(=v.c) immer noch der
    flip(v); // zuletzt eingef�gte Punkt ist.
  } 



// Neuberechnung der gesamten Triangulation von Anfang an

  public void recompute() {
    nPoints = 0;
    allCollinear = true;
    canvas.clean(); // Punktliste canvas.drawPoints bleibt erhalten
    canvas.add(this);

    ajPoint p = (ajPoint) canvas.drawPoints.anchor;
    while (p != null) {
      insertPoint(p);
      p = (ajPoint) p.getNext();
    }
  }


}

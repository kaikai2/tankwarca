//---------------------------------------------------------------------------
//
// ajElement.java
//
// Basisklasse fuer graphische Elemente
//
// PK 7.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public abstract class ajElement extends ajListElement implements ajAnimation {

  //
  // Counter f�r Ident-Nr.
  //
  public static int maxIdent = 0;

  //
  // Defaults f�r Farben etc.
  //
  public static Color backgroundColor = Color.white;
  public static Color pointColor = darker(Color.red);
  public static Color shiningColor = muchDarker(Color.orange);
  public static Color segmentColor = Color.black;
  public static Color textColor = Color.black;
  public static Color circleColor = darker(Color.green);

  public static int textSize = 10;
  public static Font textFont = new Font("Times", Font.BOLD, textSize);

// Koordinatenschranken, die auf jeden Fall den sichtbaren Bereich zwischen
// left und right sowie lower und upper enthalten, aber betragsm��ig kleiner sind
// als die H�lfte (notwendiger Sicherheitsabstand zum vereinfachten Clipping)
// der Schranken, die vom Grafiksystem als maximale Koordinaten akzeptiert werden
// (bei X-Windows ist diese Schranke nach unseren Ermittlungen 32316).

  final static int right = 10000;
  final static int left  = -right;
  final static int upper = right;
  final static int lower = -right;

  //
  // Datenelemente
  //
  public int ident;

  public Color color;
  public boolean hidden = false;

  //
  // F�r die Verwaltung in ajCanvas
  //

  public int priority = 0; // default layer

  //
  // Konstruktor
  //

  protected ajElement() {
    this(pointColor);
  }

  protected ajElement(Color c) {
    ident = setIdent();
    color = c;
  }

  private synchronized int setIdent() {
    return(++maxIdent);
  }

  protected ajElement(Color c, boolean hide) {
    this(c);
    hidden = hide;
  }

  //
  // Methoden
  //

  //
  // �berladen von Object.toString
  // Hier nur als Fehlerfall, denn ajElement ist abstract.

  public String toString() {
    return(new String("ajEl!?!"));
  }

  //
  // Malen und l�schen
  //

  public void draw( Graphics g ) {
    draw(g, color);
  }

  public void draw( Graphics g, Color c ) {
  }


// Color.brighter n�tzt nicht viel, hier ein Ersatz
// Aber Vorsicht: brighter(darker(...)) bringt meistens nicht die
// alte Farbe zur�ck!
  public static Color brighter( Color col ) {
    return new Color( more(col.getRed()),more(col.getGreen()),more(col.getBlue()) );
  }

  public static Color darker( Color col ) {
    return new Color( less(col.getRed()),less(col.getGreen()),less(col.getBlue()) );
  }

  public static Color muchBrighter( Color col ) {
    return brighter(brighter( col ));
  }

  public static Color veryMuchBrighter( Color col ) {
    return muchBrighter(muchBrighter( col ));
  }

  public static Color muchDarker( Color col ) {
    return darker(darker( col ));
  }

  public static Color veryMuchDarker( Color col ) {
    return muchDarker(muchDarker( col ));
  }

  public static int more( int i ) {
    return Math.min( 255,i+32 );
  }

  public static int less( int i ) {
    return Math.max( 0,i-32 );
  }

  //
  // Zum verschieben des gesamten Objekts
  //

  public void move( float x, float y ) {
  }

  //
  // Zum Finden des Objekts nach Koordinaten
  //

  public boolean match( int x, int y ) {
    return(false);
  }

  //
  // Animation - Leer
  //

  public void do_it( long time ) {}
}

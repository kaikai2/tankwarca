//-----------------------------------------------------------------------
//
// ajEvent
//
// Ereignisse zur Aufzeichnung von ANJA-Animationen
//
// PK 1996-08-26
//
//-----------------------------------------------------------------------

import java.io.*;

public class ajEvent {
	// Event Types

	public final static int SET_POINT = 0;				// SETP
	public final static int MOVE_POINT = 1;			// MOVP
	public final static int VIEWTYPE = 2;				// VIEW
	public final static int RESIZE = 3;					// WRES
	public final static int DOUBLE_BUFFER = 4;		// BUFD
	public final static int SHOW_REST = 5;				// UEDG
	public final static int CLEAR = 6;					// CLRC
	public final static int RM_POINT = 7;				//	DELP
	public final static int END_REC = 8;				// ENDR
	public final static int FINISH_MOVE_POINT = 9;	// FNMP
	public final static int STEP_MODE = 10;			// STPM
	public final static int STEP_SPEED = 11;			// STPS
	public final static int STEP = 12;					// STEP
	public final static int SET_CIRCLE = 13;
	public final static int RM_CIRCLE = 14;
	public final static int SET_MARK = 15;
	public final static int RM_MARK = 16;

	public int eventType;
	public long timeStamp = 0;
	public int arg1 = 0;
	public int arg2 = 0;
	public int arg3 = 0;
	public boolean barg = false;

	public ajEvent nextEvent;

	public ajEvent(int what) {
		eventType = what;
	}

	public void write(DataOutputStream os) {
		try {
			os.writeInt(eventType);
			os.writeLong(timeStamp);

			os.writeInt(arg1);
			os.writeInt(arg2);
			os.writeInt(arg3);
			os.writeBoolean(barg);
			os.flush();
		} catch(IOException ex) {
			System.err.println("Write failed.");
		}
	}

	public static ajEvent read(DataInputStream is) {
		ajEvent evt = null;
		try {
			int tp = is.readInt();
			evt = new ajEvent(tp);

			evt.timeStamp = is.readLong();
			evt.arg1 = is.readInt();
			evt.arg2 = is.readInt();
			evt.arg3 = is.readInt();
			evt.barg = is.readBoolean();
		} catch(IOException ex) {
			evt = null;
		}
		return(evt);
	}
}

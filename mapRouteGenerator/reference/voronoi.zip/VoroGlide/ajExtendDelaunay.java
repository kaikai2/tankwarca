//---------------------------------------------------------------------------
//
// ajExtendDelaunay.java
//
// Klasse f�r provisorisch erweiterbare/dynamisch bewegte
// Delaunay-Triangulationen, Voronoi-Diagramme und konvexe H�llen
//
// CI 27.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Graphics;

public class ajExtendDelaunay extends ajDelaunay {

// In diesen layers werden die Zeichenobjekte untergebracht.
  private int l = 1;
  final int oldmoveHullLayer = l++;
  final int oldmoveVorLayer = l++;
  final int oldmoveDelLayer = l++;
  final int oldrefreshLayer = l++;
  final int oldhideVorLayer = l++;
  final int oldhideDelLayer = l++;
  final int hideDelLayer = l++;
  final int hideVorLayer = l++;
  final int refreshLayer = l++;
  final int moveDelLayer = l++;
  final int moveVorLayer = l++;
  final int moveHullLayer = l++;
  final int oldrefreshPointLayer = l++;
  final int refreshPointLayer = l++;
  final int layers = l; // Anzahl der ben�tigten Zeichenebenen

// Farben zus�tzlich zu denen in ajDelaunay
  Color moveDelColor = darker(Color.gray);       // bewegte Kanten von DT
  Color hideDelColor = brighter(Color.lightGray);// versteckte Kanten von DT
  Color moveVorColor = muchBrighter(VorColor);   // bewegte K. des VD
  Color hideVorColor = brighter(veryMuchBrighter(moveVorColor));//Verst.K. des VD
  Color moveHullColor = Color.green;             // bewegte konvexe H�lle
  Color stepStarColor = shiningColor;            // Stern im Step-Modus
  Color stepFlipColor = Color.magenta;           // Kanten im Step-Modus
  Color stepCircleColor = muchDarker(Color.green);// Kreise im Step-Modus

  Color actualHideDelColor = backgroundColor;
  Color actualHideVorColor = backgroundColor;

// Variablen f�r den Einzelschrittmodus
  private boolean stepMode;
  private ajStep stepList;
  private boolean oldShowVor; // im Stepmode wird showVor und 
  private boolean oldShowDel; //    showDel vor�bergehend abgeschaltet.

// Wird gerade bewegt (nach insertTemp) oder nicht (nach endMotion)?
  private boolean moving = false;


// Konstruktor
  public ajExtendDelaunay( ajCanvas c ) {
    super(c);
    canvas.createLayers( layers );
  }


// HideColors setzen
  public void showHidden( boolean st ) {
    if (st) {
      actualHideDelColor = hideDelColor;
      actualHideVorColor = hideVorColor;
    }
    else {
      actualHideDelColor = backgroundColor;
      actualHideVorColor = backgroundColor;
    }
  }


// Am Ende einer Folge von insertTemp-Aufrufen bitte endMotion rufen
  public void endMotion() {
    moving = false;
  }

// Punkt provisorisch in die DT einf�gen

  public void insertTemp( ajPoint p ) {
    ajTriangle t,tt,ttn;

    moving = true;

    // provisorische Kanten eliminieren, alte Kanten wiederherstellen
    canvas.moveCleanLayer( moveDelLayer, oldmoveDelLayer );
    canvas.moveCleanLayer( moveVorLayer, oldmoveVorLayer );
    canvas.moveCleanLayer( moveHullLayer,oldmoveHullLayer );
    canvas.moveCleanLayer( hideDelLayer, oldhideDelLayer );
    canvas.moveCleanLayer( hideVorLayer, oldhideVorLayer );
    canvas.changeColorInLayer( oldmoveDelLayer, backgroundColor );
    canvas.changeColorInLayer( oldmoveVorLayer, backgroundColor );
    canvas.changeColorInLayer( oldmoveHullLayer,backgroundColor );
    canvas.changeColorInLayer( oldhideDelLayer, color );
    canvas.changeColorInLayer( oldhideVorLayer, VorColor );
    canvas.moveCleanLayer( refreshLayer, oldrefreshLayer );
    canvas.moveCleanLayer( refreshPointLayer, oldrefreshPointLayer );

    ajPoint pc = new ajPoint( p,shiningColor ); // Punkt kopieren
    canvas.add( pc,moveHullLayer );

    // provisorische Dreieckstruktur anlegen
    t = insertTempSimple(pc);

    if ( t == null ) // Anfangsf�lle mit kollinearen Punkten
      return;

    if ( showHull ) { // konvexe H�lle umlaufen und malen
      if ( t.bcnext.halfplane ) { // neuer Punkt pc ist au�erhalb der alten H�lle
        tt = t.bcnext;
        canvas.add( tt.a,tt.b,moveHullLayer,moveHullColor );
        tt = tt.canext;
        canvas.add( tt.a,tt.b,moveHullLayer,moveHullColor );
        canvas.add( new ajPoint(tt.a),refreshPointLayer );
        ajTriangle ttend = t.bcnext.bcnext;
        do {
          tt = tt.canext;
          canvas.add( tt.a,tt.b,moveHullLayer,HullColor );
          canvas.add( new ajPoint(tt.a),refreshPointLayer );
        } while ( tt != ttend );
      }
      else { // neuer Punkt pc ist innerhalb der alten H�lle
        tt = startTriangleHull;
        do {
          canvas.add( tt.a,tt.b,moveHullLayer,HullColor );
          canvas.add( new ajPoint(tt.a),refreshPointLayer );
          tt = tt.canext;
        } while ( tt != startTriangleHull );
      }
    }

    tt = t;
    do {
      flipTemp(tt,tt.abnext.neighbor(tt.a));
      tt = tt.canext;
    } while ( tt!=t && !tt.halfplane );

    if ( showVor ) { // die neue Voronoi-Region umlaufen und malen
      t = tt;
      if ( t.halfplane )
        ttn = t.abnext;
      else
        ttn = t.bcnext;
      do {
        canvas.add( tt.dualEdge(ttn),moveVorLayer,moveVorColor );
        if ( !tt.halfplane )
          canvas.add( tt.dualEdge(tt.abnext),moveVorLayer,moveVorColor );
        tt = ttn;
        ttn = tt.bcnext;
      } while ( tt!=t && !tt.halfplane );
    }
  }


// Punkt provisorisch in die DT einf�gen, im Einzelschrittmodus

  public void insertTemp( ajPoint p, ajStep step ) {

    if ( allCollinear )
      return;

    stepMode = true;
    stepList = step;
    oldShowVor = showVor;
    oldShowDel = showDel;
    showVor = false;
    showDel = false;

    ajTriangle t,tt;

    p.color = shiningColor;

    // provisorische Dreieckstruktur anlegen
    t = insertTempSimple(p);

    tt = t;
    stepList.add( tt.a,refreshPointLayer,pointColor );
    do {
      stepList.add( tt.a,tt.b,moveDelLayer,stepStarColor );
      stepList.add( tt.b,refreshPointLayer,pointColor );
      tt = tt.canext;
    } while ( tt!=t && !tt.halfplane );

    stepList.pause();

    tt = t;
    stepList.add( tt.b,p,moveDelLayer,moveDelColor );
    do {
      stepList.add( tt.a,p,moveDelLayer,moveDelColor );
      tt = tt.canext;
    } while ( tt!=t && !tt.halfplane );

    stepList.pause();

    tt = t;
    do {
      flipTemp( tt,tt.abnext.neighbor(tt.a) );
      tt = tt.canext;
    } while ( tt!=t && !tt.halfplane );

    stepList.pause(2);
    stepList.add( p,refreshPointLayer,pointColor ); // nur um die Pause
                                                    // wirklich zu machen

    p.color = pointColor;
    stepMode = false;
    showVor = oldShowVor;
    showDel = oldShowDel;
  }


// Punkt p provisorisch dort einf�gen, wo er lokalisiert wird.
// Das globale startTriangle ist dieses Dreieck, in dem p liegt.
// Zur�ckgegeben wird ein (echtes) provisorisches Dreieck, an dem der neue
// Punkt beteiligt ist; wenn p au�erhalb der konvexen H�lle liegt, dann das
// erste im Gegenuhrzeigersinn.
// Bei nPoints<=2 (d. h. am Anfang) wird null zur�ckgegeben.

  private ajTriangle insertTempSimple( ajPoint p ) {

    if ( !allCollinear ) { // es gibt sowieso schon 3 nicht-kollineare Punkte
      startTriangle = startTriangle.find(p);
         // das n�chste mal hier zu suchen anfangen
      if (startTriangle.halfplane)
        return extendOutsideTemp(startTriangle,p);
      else
        return extendInsideTemp(startTriangle,p);
    }

    if ( stepMode ) // im kollinearen Fall kann man sowieso nichts im
      return null;  // Einzelschrittmodus anzeigen.

    if ( nPoints == 0 ) // p ist erster Punkt, nichts zu tun
      return null;

    if ( nPoints == 1 ) { // p ist zweiter Punkt, firstP ist der erste
      canvas.add( new ajPoint(firstP),refreshPointLayer );
      if ( showDel ) {
        canvas.add( firstP,p,moveDelLayer,moveDelColor );
      }
      if ( showVor ) {
        canvas.add( p.Bisector(firstP),moveVorLayer,moveVorColor );
      }
      return null;
    }

    // bleibt der Fall, da� nPoints>=2 kollineare Punkte schon da sind
    // und p provisorisch hinzugef�gt wird.

    if ( showHull ) {
      canvas.add( new ajPoint(firstP),refreshPointLayer );
      canvas.add( new ajPoint(lastP), refreshPointLayer );
      canvas.add( firstP,p,moveHullLayer,moveHullColor );
      canvas.add( p,lastP,moveHullLayer,moveHullColor );
      canvas.add( lastP,firstP,moveHullLayer,HullColor );
    }

    switch ( p.pointLineTest(firstP,lastP) ) {
      case ajPoint.LEFT:         // Punkte sind jetzt nicht mehr kollinear:
        firstNonCollinearTemp( extendOutsideTemp(firstT.abnext,p) );
        break;
      case ajPoint.RIGHT:
        firstNonCollinearTemp( extendOutsideTemp(firstT,p) );
        break;
      case ajPoint.ONSEGMENT:    // Punkte sind weiterhin kollinear:
        insertCollinearTemp( p, ajPoint.ONSEGMENT );
        break;
      case ajPoint.INFRONTOFA:
        insertCollinearTemp( p, ajPoint.INFRONTOFA );
        break;
      case ajPoint.BEHINDB:
        insertCollinearTemp( p, ajPoint.BEHINDB );
        break;
    }
    return null;
  } // Ende insertTempSimple


  private void firstNonCollinearTemp( ajTriangle t ) {

    if ( !showVor )
      return;

    ajTriangle tt = t;
    canvas.add( tt.dualEdge(tt.bcnext),moveVorLayer,moveVorColor );
    while ( !tt.halfplane ) {
      canvas.add( tt.dualEdge(tt.abnext),moveVorLayer,moveVorColor );
      canvas.add( tt.dualEdge(tt.canext),moveVorLayer,moveVorColor );
      tt = tt.canext;
    }
  }


  private void insertCollinearTemp( ajPoint p, int res ) {

    ajTriangle t = firstT;

    switch ( res ) {
      case ajPoint.INFRONTOFA:
        if ( showDel )
          canvas.add( firstP,p,moveDelLayer,moveDelColor );
        if ( showVor )
          canvas.add( firstP.Bisector(p),moveVorLayer,moveVorColor );
        break;
      case ajPoint.BEHINDB:
        if ( showDel )
          canvas.add( lastP,p,moveDelLayer,moveDelColor );
        if ( showVor )
          canvas.add( lastP.Bisector(p),moveVorLayer,moveVorColor );
        break;
      case ajPoint.ONSEGMENT:
        while ( p.isGreater(t.a) ) {
          canvas.add( new ajPoint(t.b),refreshPointLayer );
          if ( showVor )
            canvas.add( t.a.Bisector(t.b),moveVorLayer,VorColor );
          if ( showDel )
            canvas.add( t.a,t.b,moveDelLayer,color );
          t = t.canext;
        }
        canvas.add( new ajPoint(t.b),refreshPointLayer );
        if ( showVor ) {
          canvas.add( t.a.Bisector(p),moveVorLayer,moveVorColor );
          canvas.add( t.b.Bisector(p),moveVorLayer,moveVorColor );
        }
        if ( showDel )
          canvas.add( t.a,t.b,moveDelLayer,moveDelColor );
        t = t.canext;
        break;
    }
    while ( t.b != lastP ) {
      canvas.add( new ajPoint(t.b),refreshPointLayer );
      if ( showVor )
        canvas.add( t.a.Bisector(t.b),moveVorLayer,VorColor );
      if ( showDel )
        canvas.add( t.a,t.b,moveDelLayer,color );
      t = t.canext;
    }
    canvas.add( new ajPoint(lastP),refreshPointLayer );
  }



// Triangulation anlegen, d. h. erstes provisorisches Dreieck bauen, �berfl�ssig?

  private ajTriangle startTriangulationTempA( ajPoint A, ajPoint B, ajPoint C ) {

    ajTriangle t=null;
    int res = C.pointLineTest(A,B);

    if ( (res == ajPoint.LEFT) || (res == ajPoint.BEHINDB) )
      t = new ajTriangle( A,B,C );
    else if ( (res == ajPoint.RIGHT) || (res == ajPoint.ONSEGMENT) )
      t = new ajTriangle( A,C,B );
    else if (res == ajPoint.INFRONTOFA)
      t = new ajTriangle( C,A,B );
      
    ajTriangle h1=new ajTriangle( t.b,t.a );
    ajTriangle h2=new ajTriangle( t.c,t.b );
    ajTriangle h3=new ajTriangle( t.a,t.c );
    t.abnext=h1; h1.abnext=t;
    t.bcnext=h2; h2.abnext=t;
    t.canext=h3; h3.abnext=t;
    h1.canext=h2;  h2.bcnext=h1;
    h2.canext=h3;  h3.bcnext=h2;
    h3.canext=h1;  h1.bcnext=h3;
    return t;
  }


// Punkt p im inneren Dreick t provisorisch einf�gen.
// Es wird vorausgesetzt, da� t ein Dreieck ist, das p enth�lt,
// Alle neuen provisorischen Dreiecke bekommen p als ihren Punkt c,
// ein solches wird zur�ckgegeben.

  private ajTriangle extendInsideTemp( ajTriangle t, ajPoint p ) {

    ajTriangle h1,h2,h3;
    h1 = treatDegeneracyInsideTemp( t,p );
    if ( h1 != null ) return h1;

    h1 = new ajTriangle( t.a,t.b,p );
    h2 = new ajTriangle( t.b,t.c,p );
    h3 = new ajTriangle( t.c,t.a,p );
    h1.abnext = t.abnext;
    h2.abnext = t.bcnext;
    h3.abnext = t.canext;
    h1.bcnext = h2;
    h2.canext = h1;
    h2.bcnext = h3;
    h3.canext = h2;
    h3.bcnext = h1;
    h1.canext = h3;

    if ( showDel ) {
      canvas.add( t.a,p,moveDelLayer,moveDelColor );
      canvas.add( t.b,p,moveDelLayer,moveDelColor );
      canvas.add( t.c,p,moveDelLayer,moveDelColor );
    }
    canvas.add( new ajPoint(t.a),refreshPointLayer );
    canvas.add( new ajPoint(t.b),refreshPointLayer );
    canvas.add( new ajPoint(t.c),refreshPointLayer );
    return h1;
  }


// Degenerierte F�lle beim inneren Einf�gen testen und ggfs. behandeln

  private ajTriangle treatDegeneracyInsideTemp( ajTriangle t, ajPoint p ) {

    if ( t.abnext.halfplane && p.pointLineTest(t.b,t.a) == ajPoint.ONSEGMENT )
      return extendOutsideTemp( t.abnext,p );
    if ( t.bcnext.halfplane && p.pointLineTest(t.c,t.b) == ajPoint.ONSEGMENT )
      return extendOutsideTemp( t.bcnext,p );
    if ( t.canext.halfplane && p.pointLineTest(t.a,t.c) == ajPoint.ONSEGMENT )
      return extendOutsideTemp( t.canext,p );
    return null;
  }


// Punkt p im �u�eren Dreick t provisorisch einf�gen.
// Es wird vorausgesetzt, da� t eine Halbebene ist, die p enth�lt,
// Alle neuen (echten) provisorischen Dreiecke bekommen p als ihren Punkt c.
// Zur�ck kommt das erste der entstehenden geschlossenen Dreiecke.

  private ajTriangle extendOutsideTemp( ajTriangle t, ajPoint p ) {

    if ( p.pointLineTest(t.a,t.b) == ajPoint.ONSEGMENT ) { // degenerate
      ajTriangle dg = new ajTriangle( t.a,t.b,p );
      ajTriangle hp1 = new ajTriangle( t.a,p );
      ajTriangle hp2 = new ajTriangle( p,t.b );
      dg.abnext = t.abnext;
      dg.bcnext = hp2;
      hp2.abnext = dg;
      dg.canext = hp1;
      hp1.abnext = dg;
      hp2.bcnext = t.bcnext;
      hp2.canext = hp1;
      hp1.bcnext = hp2;
      hp1.canext = t.canext;
      if ( showDel ) {
        canvas.add( t.a,p,moveDelLayer,moveDelColor );
        canvas.add( t.b,p,moveDelLayer,moveDelColor );
      }
      canvas.add( new ajPoint(t.a),refreshPointLayer );
      canvas.add( new ajPoint(t.b),refreshPointLayer );
      return dg;
    }
    ajTriangle h1,h2,t1,t2,prev1,prev2;
    h1 = new ajTriangle( t.a,t.b,p );
    h1.abnext = t.abnext;
    if ( showDel ) {
      canvas.add( t.a,p,moveDelLayer,moveDelColor );
      canvas.add( t.b,p,moveDelLayer,moveDelColor );
      if ( allCollinear )
        canvas.add( t.a,t.b,refreshLayer,color );
    }
    canvas.add( new ajPoint(t.a),refreshPointLayer );
    canvas.add( new ajPoint(t.b),refreshPointLayer );
    t1 = t.canext;
    prev1 = h1;
    while ( p.pointLineTest(t1.a,t1.b) < ajPoint.RIGHT ) {
      if ( showDel ) {
        canvas.add( t1.a,p,moveDelLayer,moveDelColor );
        if ( allCollinear )
          canvas.add( t1.a,t1.b,refreshLayer,color );
      }
      canvas.add( new ajPoint(t1.a),refreshPointLayer );

      h2 = new ajTriangle( t1.a,t1.b,p );
      h2.abnext = t1.abnext;
      h2.bcnext = prev1;
      prev1.canext = h2;
      prev1 = h2;
      t1 = t1.canext;
    }

    h2 = new ajTriangle( prev1.a,p );
    h2.abnext = prev1;
    prev1.canext = h2;
    h2.canext = t1;
    prev1 = h2;

    t2 = t.bcnext;
    prev2 = h1;
    while ( p.pointLineTest(t2.a,t2.b) < ajPoint.RIGHT ) {
      if ( showDel ) {
        canvas.add( t2.b,p,moveDelLayer,moveDelColor );
        if ( allCollinear )
          canvas.add( t2.a,t2.b,refreshLayer,color );
      }
      canvas.add( new ajPoint(t2.b),refreshPointLayer );

      h2 = new ajTriangle( t2.a,t2.b,p );
      h2.abnext = t2.abnext;
      h2.canext = prev2;
      prev2.bcnext = h2;
      prev2 = h2;
      t2 = t2.bcnext;
    }

    h2 = new ajTriangle( p,prev2.b );
    h2.abnext = prev2;
    prev2.bcnext = h2;
    h2.bcnext = t2;

    h2.canext = prev1;
    prev1.bcnext = h2;

    return prev2;
  }


// flipTemp macht, falls erforderlich, einen prov. edge flip und rekursiv weiter.
// t ist ein provisorisches Dreieck, t.c ist der provisorisch eingef�gte Punkt.
// Bedingung f�r den edge flip ist, da� t.c im Umkreis von t.abnext liegt.
// o ist das originale Dreieck, das auch zu t.abnext an derselben Kante
// wie t benachbart ist, d. h. t �berdeckt o teilweise.

  public void flipTemp( ajTriangle t, ajTriangle o ) {

    ajTriangle u=t.abnext, v;

    if ( showVor ) {
      canvas.add( o.dualEdge(u),hideVorLayer,actualHideVorColor );
    }
    if ( stepMode ) {
      stepList.add( t.a,t.b,moveDelLayer,stepFlipColor );
      stepList.pause();
      if ( !u.halfplane ) {
        stepList.add( u.circum,oldmoveDelLayer,stepCircleColor );
        stepList.pause();
        stepList.remove( u.circum,oldmoveDelLayer );
      }
    }

    if ( u.halfplane || !u.circumcircle_contains(t.c) ) { // kein Flip n�tig
      if ( showDel )
        canvas.add( t.a,t.b,refreshLayer,color ); // aber Rand sauber neu malen
      if ( stepMode ) {
        stepList.add( t.a,t.b,moveDelLayer,stepStarColor );
      }
      return;
    }
                                                         // Flip ist n�tig
    if ( t.a == u.a ) {
      v = new ajTriangle( t.a,u.b,t.c );
      v.abnext = u.abnext;
      t.abnext = u.bcnext;
    } 
    else if ( t.a == u.b ) {
      v = new ajTriangle( t.a,u.c,t.c );
      v.abnext = u.bcnext;
      t.abnext = u.canext;
    }
    else if ( t.a == u.c ) {
      v = new ajTriangle( t.a,u.a,t.c );
      v.abnext = u.canext;
      t.abnext = u.abnext;
    }
    else {
      System.out.println( "Error in flipTemp." );
      return;
    }

    v.canext=t.canext;                              // das ist der echte Flip
    v.canext.switchneighbors(t,v);                  // in der Datenstruktur...
    v.bcnext=t;
    t.canext=v;
    t.a = v.b;
    t.circumcircle(); 

    if ( showDel ) {                               // ... und auf dem Bildschirm
      canvas.add( v.a,t.b,hideDelLayer,actualHideDelColor );
      canvas.add( t.a,t.c,moveDelLayer,moveDelColor );
    }
    canvas.add( new ajPoint(t.a),refreshPointLayer );
    if ( stepMode ) {
      stepList.add( v.a,t.b,moveDelLayer,actualHideDelColor );
      stepList.add( t.a,t.c,moveDelLayer,moveDelColor );
      stepList.add( t.b,t.c,moveDelLayer,moveDelColor );
      stepList.add( v.a,t.c,moveDelLayer,moveDelColor );
      stepList.add( t.a,refreshPointLayer,pointColor );
      stepList.add( t.a,t.b,moveDelLayer,stepStarColor );
      stepList.add( v.a,v.b,moveDelLayer,stepStarColor );
      stepList.pause();
    }

                   // rekursiv weiter.
    flipTemp(t,u); // Man beachte, da� t.c immer noch der
  }                // provisorische Punkt ist.


// Anzeigen der Triangulation bzw. des Dualen bzw. der H�lle

  public void draw( Graphics g ) {

    if ( !allCollinear ) {
      if ( showDel ) {
        g.setColor(color);
        startTriangle.visitAndDraw(g);
      }
      if ( showVor ) {
        g.setColor( VorColor );
        startTriangle.visitAndDrawDual(g);
      }
    }                    // bleibt noch der kollineare Fall
    else if ( nPoints >= 2 ) { // sonst gibt's noch nicht einmal firstT
      ajTriangle u = firstT;
      while ( u.b != lastP ) {
        if ( showDel ) {
          g.setColor( color );
          ajSegment.drawLineSegment( g,u.b,u.a );
        }
        if ( showVor && !(moving && allCollinear) ) {
          g.setColor( VorColor );
          ajLine.drawBisector( g,u.b,u.a );
        }
        u = u.canext;
      }
    }
    if ( showHull && !moving && nPoints >= 2 ) {
      g.setColor( HullColor );
      startTriangleHull.visitAndDrawHull(g);
    } 
  }


}

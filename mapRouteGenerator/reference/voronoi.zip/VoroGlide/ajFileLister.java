//-----------------------------------------------------------------------
//
// FileLister
//
// Listet Files zu einem Basisdirectory auf und gibt selektiertes
// aus.
//
// PK 1996-08-30
//
//-----------------------------------------------------------------------

import java.awt.*;
import java.io.*;
import java.lang.*;

public class ajFileLister extends Frame implements Runnable {
	private Thread thr;
	private StringBuffer selected = null;
	private List list;
	private TextField infoarea;
	private TextField new_name;
	private TextField dir_name;
	private Panel buttons;
	private Button parent, cancel, accept;
	private FilenameFilter filter;
	private File cwd;
	private String[] entries;
   private boolean finished = false;
   private String directory;
	private Thread listener;
	private boolean allow_new;
	private String suff;

	public ajFileLister(String suffix, Thread listener, StringBuffer selected, String directory, FilenameFilter filter) throws IOException {
		this(suffix, listener, selected, directory, filter, false);
	}

	public ajFileLister(String suffix, Thread listener, StringBuffer selected, String directory, FilenameFilter filter, boolean allow_new) throws IOException {
		super("File Selector");
		this.selected = selected;
		selected.setLength(0);
		this.suff = suffix;
		this.directory = directory;
		this.filter = filter;
		this.listener = listener;
		this.allow_new = allow_new;
	}

	public void start() {
		this.setLayout(new GridBagLayout());

		list = new List(12, false);
		infoarea = new TextField();
		dir_name = new TextField();

		infoarea.setEditable(false);
		buttons = new Panel();
		parent = new Button("chdir ..");
      cancel = new Button("Cancel");
      accept = new Button("Accept");
		buttons.add(parent);
		buttons.add(cancel);
		buttons.add(accept);

		LayoutTools.gridBagConstrain(this, dir_name, 1, 0, 1, 1, GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER, 1.0, 0.0, 0, 0, 0, 0);

		LayoutTools.gridBagConstrain(this, list, 1, 1, 1, 1, GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER, 1.0, 0.0, 0, 0, 0, 0);

		LayoutTools.gridBagConstrain(this, buttons, 1, 2, 1, 1, GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER, 1.0, 0.0, 0, 0, 0, 0);

		new_name = new TextField("", 80);
		new_name.setEditable(allow_new);
		LayoutTools.gridBagConstrain(this, new_name, 1, 3, 1, 1, GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER, 1.0, 0.0, 0, 0, 0, 0);
		LayoutTools.gridBagConstrain(this, infoarea, 1, 4, 1, 1, GridBagConstraints.HORIZONTAL,
			GridBagConstraints.CENTER, 1.0, 0.0, 0, 0, 0, 0);

		this.resize(550, 400);
		this.show();

		try {
			list_directory(directory);
		} catch(IOException e) {
			finished = true;
			stop();
		}
		if(thr == null) {
			thr = new Thread(this);
			thr.start();
		}
	}

	public void run() {
		while(!finished) {
			try {
				Thread.sleep(200);
			} catch(InterruptedException ie) {}
		}
	}

	public synchronized void stop() {
		hide();
		if(thr != null && thr.isAlive()) {
			synchronized(listener) {
				listener.notify();
			}
			thr.stop();
		}
		thr = null;
	}

	public void list_directory(String directory) throws IOException {
		File dir = new File(directory);

		if(!dir.isDirectory())
			throw new IllegalArgumentException("ajFileLister: no such directory");
		list.clear();
		cwd = dir;
		this.dir_name.setText(directory);

		entries = cwd.list(filter);
		for(int i = 0; i < entries.length; i++)
			list.addItem(entries[i]);
	}

	public void show_info(String filename) throws IOException {
		File f = new File(cwd, filename);
		String info;

		if(!f.exists())
			throw new IllegalArgumentException("ajFileLister.showInfo(): no such file or directory");

		if(f.isDirectory()) info = "Directory: ";
		else info = "File: ";

		info += filename + " ";

		info += (f.canRead() ? "r" : " ") + " "
				+ (f.canWrite() ? "w" : " ") + " "
				+  f.length() + " " + new java.util.Date(f.lastModified());
		infoarea.setText(info);
	}

	public boolean handleEvent(Event e) {
		if(e.target == accept) {
			hide();
			finished = true;
			stop();
			return true;
		} else if(e.target == cancel) {
			selected.setLength(0);
			hide();
			finished = true;
			stop();
			return true;
		} else if(e.target == parent) {
			String parent = cwd.getParent();
			if(parent == null)
				parent = "/";
			try {
				list_directory(parent);
			} catch(IllegalArgumentException ex) {
				infoarea.setText("Already at top");
			} catch(IOException ex) {
				infoarea.setText("I/O Error");
			}
			return true;
		} else if(e.target == list) {
			if(e.id == Event.LIST_SELECT) {
				try {
					String name = entries[((Integer) e.arg).intValue()];
					File sel = new File(name);
					show_info(name);
					if(sel.isFile()) {
						new_name.setText(sel.getAbsolutePath());
						selected.setLength(0);
						selected.append(sel.getAbsolutePath());
					}
				} catch(IOException ex) {
					infoarea.setText("I/O Error");
				}
			} else if(e.id == Event.ACTION_EVENT) {
				try {
					String item = new File(cwd, (String) e.arg).getAbsolutePath();
					try {
						list_directory(item);
					} catch(IllegalArgumentException ex) {
						selected.setLength(0);
						selected.append(item);
						finished = true;
						hide();
						stop();
					}
				} catch(IOException ex) {
					infoarea.setText("I/O Error");
				}
			}
			return true;
		} else if(e.target == new_name) {
			if(e.id == Event.ACTION_EVENT) {
				try {
					File f = null;
					try {
						f = new File((String) e.arg);
					} catch(NullPointerException nullex) {
						System.out.println(cwd + "[" + e.arg + "]");
						f = new File(cwd, (String) e.arg);
					}
					String item = f.getAbsolutePath();
					f = new File(item);
					try {
						list_directory(f.getParent());
					} catch(IllegalArgumentException illex) {
						infoarea.setText("no directory " + f.getParent());
					}
					if(!f.exists() || (f.isFile() && f.canWrite())) {
						selected.setLength(0);
						selected.append(item);
						if(!item.endsWith(suff))
							selected.append(suff);

						new_name.setText(selected.toString());
					} else {
						new_name.setText("");
						if(f.isDirectory()) {
							list_directory(item);
						} else
							infoarea.setText("not a valid filename.");
					}
				} catch(IOException ex) {
					infoarea.setText("I/O Error");
				}
			} else if(e.id == Event.KEY_PRESS) {
				
			}
		}
		return super.handleEvent(e);
	}
}

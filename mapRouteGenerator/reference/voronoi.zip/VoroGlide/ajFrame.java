//--------------------------------------------------------------------------
//
// ajFrame
//
// Frame fuer anja Applets
//
// PK 1996-11-07
//
//--------------------------------------------------------------------------

import java.applet.*;
import java.awt.*;
import java.net.*;
import java.io.*;

public class ajFrame extends Frame {
	VoronoiApplet va;

	Menu fm, sm, em, om, hm;

	MenuItem close;
	CheckboxMenuItem shVor, shDel, shConv;
	CheckboxMenuItem unBuf, thin;
	MenuItem clr;
	CheckboxMenuItem demo;
	CheckboxMenuItem step;
	MenuItem manual, quick, about;

	public ajFrame(VoronoiApplet a, String title, int w, int h) {
		super(title);
		va = a;

		resize(w, h);

		MenuBar mb = new MenuBar();

		fm = new Menu("File");
		sm = new Menu("Show");
		em = new Menu("Edit");
		om = new Menu("Options");
		hm = new Menu("Help");

		close = new MenuItem("Close");

		fm.add(close);

		shVor = new CheckboxMenuItem("Voronoi");
		shDel = new CheckboxMenuItem("Delaunay");
		shConv = new CheckboxMenuItem("Convex Hull");

		sm.add(shVor);
		sm.add(shDel);
		sm.add(shConv);

		clr = new MenuItem("Clear");
		demo = new CheckboxMenuItem("Run Demo");

		em.add(clr);
		em.addSeparator();
		em.add(demo);

		unBuf = new CheckboxMenuItem("Unbuffered Display");
		thin = new CheckboxMenuItem("Thin Lines");

		Menu delm = new Menu("Delaunay");

		step = new CheckboxMenuItem("Step Mode");

		delm.add(step);

		om.add(unBuf);
		om.add(thin);
		om.addSeparator();
		om.add(delm);

		manual = new MenuItem("Manual");
		quick = new MenuItem("Quick Help");
		about = new MenuItem("About...");

		hm.add(about);
		hm.addSeparator();
		hm.add(quick);
		hm.add(manual);

		mb.add(fm);
		mb.add(sm);
		mb.add(em);
		mb.add(om);
		mb.add(hm);
		mb.setHelpMenu(hm);

		setMenuBar(mb);
	}

	public boolean keyDown(Event evt, int key) {
		return(va.keyDown(evt, key));
	}

	public boolean action(Event evt, Object obj) {
		if(evt.id == Event.ACTION_EVENT) {
			if(evt.target == close) {
				va.recFrame.hide();
				va.stepFrame.hide();
				hide();
				return true;
			} else if(evt.target == shVor || evt.target == shDel 
                   || evt.target == shConv) {
				va.setViewtype(shVor.getState(), shDel.getState(), shConv.getState());
				return true;
			} else if(evt.target == clr) {
				va.clear_canvas();
				return true;
			} else if(evt.target == demo) {
				if(demo.getState() == true) {
					if(va.recPanel.load.isEnabled()) {
						va.evRec.save_op = false;

						va.evRec.selected.setLength(0);
						va.evRec.selected.append("demo.ani");
						va.evRec.load_save();

						if(va.evRec.hasRecord()) {
							va.do_replay();
						} else {
							demo.setState(false);
							demo.disable();
						}
					}
				} else {
					va.do_stop();
				}
				return true;
			} else if(evt.target == unBuf) {
				va.unBufferedDisplay(unBuf.getState());
				return true;
			} else if(evt.target == thin) {
				va.thinLines(thin.getState());
				return true;
			} else if(evt.target == step) {
				va.stepMode = step.getState();
				va.evRec.recordEvent(ajEvent.STEP_MODE, va.stepMode);
				return true;
			} else if(evt.target == about) {
				String msg = "VoroGlide\nVersion 2.2, May 2001\n"
								+" \n"
								+"Written in Java at\n"
								+"FernUniversit�t Hagen, Praktische Informatik VI\n"
								+" \n"
								+"by\n"
								+" \n"
								+"Christian Icking, Rolf Klein, Peter K�llner,\n"
								+"Elmar Langetepe, Lihong Ma\n"
								+" \n"
								+"email: javagroup@fernuni-hagen.de";
				ajMsgFrame vab = new ajMsgFrame("About VoronoiApplet",
"VoroGlide\n"+
"Version 2.2, May 2001\n"+
" \n"+
"Written in Java at\n"+
"FernUniversit�t Hagen, Praktische Informatik VI\n"+
" \n"+
"by\n"+
" \n"+
"Christian Icking, Rolf Klein, Peter K�llner, Lihong Ma\n"+
" \n"+
"email: javagroup@fernuni-hagen.de"
				);
				vab.show();
				return true;
			} else if(evt.target == quick) {
				ajMsgFrame qh = new ajMsgFrame("VoroGlide 2.2 Quick Help",
"VoroGlide 2.2 Quick Help\n"+
" \n"+
"Push left mouse button to set point.\n"+
"Push right mouse button (or <Alt> mouse) to remove point.\n"+
"Drag mouse with left button pressed to move point.\n"+
" \n"+
"Menus\n"+
" \n"+
"File: Close the applet frame.\n"+
"Show: Select a combination of diagrams to be shown.\n"+
"Edit: Clear canvas, Run demo animation.\n"+
"Options:\n"+
" -Unbuffered (somewhat jagged, sometimes faster) vs. buffered display (smoother, default)\n"+
" -Thin (faster) vs. thick lines (nicer for presentations, default)\n"+
" -Delaunay: Step Mode: Display animation of Edge Flip Algorithm on point insertion."
                                , MultiLineLabel.LEFT);
				qh.show();
				return true;
			} else if(evt.target == manual) {
				URL hurl;
				try {
					hurl = new URL(va.getCodeBase(), va.getHelpURL());
				} catch(MalformedURLException mex) {
					hurl = null;
				}
				if(hurl != null) {
					va.getAppletContext().showDocument(hurl, "VoroGlide User Manual");
				}
				return true;
			}
		}
		return(va.action(evt, obj));
	}
}

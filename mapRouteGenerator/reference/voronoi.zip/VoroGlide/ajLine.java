//---------------------------------------------------------------------------
//
// ajLine.java
//
// Klasse f�r Geraden
//
// CI 24.8.1996
//
//---------------------------------------------------------------------------


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class ajLine extends ajSegment {

// Die Gerade geht durch die Punkte a und b.


// Konstruktoren

  public ajLine( ajPoint A, ajPoint B ) {
    super(A,B);
  }

  public ajLine( ajPoint A, ajPoint B, Color col ) {
    super(A,B,col);
  }


// Gerade malen (Vorsicht, drawLine ist hier nicht Graphics.drawLine )

  public void draw( Graphics g ) {
    g.setColor(color);
    drawLine(g,a,b);
  }

  public void draw( Graphics g, Color c ) {
    g.setColor(c);
    drawLine(g,a,b);
  }

  public static void drawLine( Graphics g, ajPoint a, ajPoint b ) {
    drawLine( g, a.x,a.y, b.x,b.y );
  }

  public static void drawLine( Graphics g, float ax, float ay,
                                           float bx, float by ) {
    float dx = bx-ax;
    float dy = by-ay;

    if ( Math.abs(dx) >= Math.abs(dy) ) {
      drawLineSegment( g,left, Math.round(dy/dx*(left-ax)+ay),
                         right,Math.round(dy/dx*(right-ax)+ay) );
    }
    else {
      drawLineSegment( g,Math.round(dx/dy*(lower-ay)+ax),lower,
                         Math.round(dx/dy*(upper-ay)+ax),upper );
    }
  }


// mittelsenkrechte Gerade malen

  public static void drawBisector( Graphics g, ajPoint a, ajPoint b ) {

    float sx = (a.x+b.x)/2;
    float sy = (a.y+b.y)/2;
    float dx = b.x-a.x;
    float dy = b.y-a.y;
    drawLine( g, sx-dy,sy+dx, sx+dy,sy-dx );
  }

}

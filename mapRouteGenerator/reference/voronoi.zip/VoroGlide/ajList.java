//--------------------------------------------------------------------------
//
// ajList.java
//
// Interface f�r eine doppelt verkettete Liste
//
// 12.08.1996 PK
//
//--------------------------------------------------------------------------

public class ajList {
  public ajListElement anchor = null;
  public ajListElement last = null;


// append: el wird am Ende der Liste angeh�ngt

  public void append(ajListElement el) {
    if(last != null) {
      last.append(el);
	 } else {
      anchor = el;
		el.nextElement = null;
      el.prevElement = null;
	 }
    last = el;
  }


// insert: el wird am Anfang der Liste eingef�gt

  public void insert(ajListElement el) {
     if(anchor != null)
       anchor.insert(el);
     else {
       last = el;
       el.nextElement = null;
       el.prevElement = null;
	  }
     anchor = el;
  }


// insert: el1 wird vor el2 in die Liste eingef�gt,
// es wird nicht �berpr�ft, ob el2 tats�chlich in dieser Liste ist!
// el2 == null bedeutet: am Ende anh�ngen

  public void insert(ajListElement el1, ajListElement el2 ) {
    if (el2 == null)
      append(el1);
    else if (el2 == anchor)
      insert(el1);
    else
      el2.insert(el1);
  }


// remove: e wird aus der Liste entfernt,
// es wird nicht �berpr�ft, ob e tats�chlich in dieser Liste ist!

  public void remove(ajListElement e) {
    if(e == anchor)
      anchor = e.getNext();
    if(e == last)
      last = e.getPrev();
    e.removeFromList();
  }


// isEmpty: Ist diese Liste leer?

  public boolean isEmpty() {
    return anchor==null;
  }


// toString: Inhalt der Liste ausgeben

  public String toString() {
    ajListElement t = anchor;
    StringBuffer str = new StringBuffer( "" );
    while (t != null) {
System.out.println( "toString"+t );
      str.append( " "+t.toString()+"\n" );
      t = t.getNext();
    }
    return str.toString();
  }

}

//--------------------------------------------------------------------------
//
// ajListElement.java
//
// Interface f�r Elemente einer doppelt verketteten Liste
//
// 12.08.1996 PK
//
//--------------------------------------------------------------------------

public abstract class ajListElement {
  ajListElement prevElement = null;
  ajListElement nextElement = null;

  public ajListElement getNext() {
    return(nextElement);
  }

  public ajListElement getPrev() {
    return(prevElement);
  }

// append: el wird hinter this eingef�gt
  public void append(ajListElement el) {
    el.prevElement = this;
    el.nextElement = nextElement;

    if(el.nextElement != null)
      el.nextElement.prevElement = el;

    nextElement = el;
  }

// insert: el wird vor this eingef�gt
  public void insert(ajListElement el) {
    el.nextElement = this;
    el.prevElement = prevElement;
    if(el.prevElement != null)
      el.prevElement.nextElement = el;

    prevElement = el;
  }

// removeFromList: this wird aus seiner Liste entfernt
  public void removeFromList() {
    if(prevElement != null)
      prevElement.nextElement = nextElement;
    if(nextElement != null)
      nextElement.prevElement = prevElement;
    prevElement = null;
    nextElement = null;
  }
}

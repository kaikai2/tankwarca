//------------------------------------------------------------------------
//
// ajMsgFrame.java
//
// Infobox fuer Voronoi-Applet
//
// PK 1996-11-14
//
//------------------------------------------------------------------------

import java.applet.*;
import java.awt.*;

public class ajMsgFrame extends Frame {
	Button button;
	MultiLineLabel label;

	ajMsgFrame(String title, String msg) {
		this(title, msg, MultiLineLabel.CENTER);
	}

	ajMsgFrame(String title, String msg, int align) {
		super(title);

		setLayout(new BorderLayout(15, 15));

		label = new MultiLineLabel(msg, align);
		add("Center", label);

		label.setFont(new Font("Helvetica", Font.BOLD, 14));

		button = new Button("OK");

		Panel p =new Panel();
		p.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

		p.add(button);
		add("South", p);

		pack();
	}

	public boolean action(Event evt, Object obj) {
		if(evt.target == button) {
			hide();
			dispose();
			return true;
		}
		return false;
	}

	public boolean gotFocus(Event evt, Object obj) {
		button.requestFocus();
		return true;
	}
}

//---------------------------------------------------------------------------
//
// ajPointList.java
//
// Klasse f�r Listen von Punkten, in die man lexikographisch geordnet
// einf�gen kann.
//
// CI,LM 3.12.1996
//
//---------------------------------------------------------------------------

public class ajPointList extends ajList {

  public void insertLex ( ajPoint p ) {

    ajPoint q  = (ajPoint) anchor;

    while ( (q!=null) && p.isGreater(q) )
      q = (ajPoint) q.getNext();

    // jetzt ist q==null oder p<=q
    // p soll vor q eingef�gt werden
    insert(p,q);
  }
}

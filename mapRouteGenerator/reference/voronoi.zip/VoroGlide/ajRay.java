//---------------------------------------------------------------------------
//
// ajRay.java
//
// Klasse f�r Strahlen
//
// LM 19.8.1996
//
//---------------------------------------------------------------------------


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class ajRay extends ajSegment {

// Punkt a ist der Anfangspunkt, der Strahl geht durch Punkt b,
// Konstruktoren wie ajSegment.


// Konstruktoren

  public ajRay( ajPoint A, ajPoint B ) {
    super(A,B);
  }

  public ajRay( ajPoint A, ajPoint B, Color col ) {
    super(A,B,col);
  }


// Strahl malen

  public void draw( Graphics g ) {
    g.setColor(color);
    drawRay(g,a,b);
  }

  public void draw( Graphics g, Color c ) {
    g.setColor(c);
    drawRay(g,a,b);
  }

  public static void drawRay( Graphics g, ajPoint a, ajPoint b ) {
    drawRay(g, a.x,a.y, b.x,b.y);
  }

  public static void drawRay( Graphics g, ajPoint a, float bx, float by ) {
    drawRay(g, a.x,a.y, bx,by);
  }

  public static void drawRay( Graphics g, float ax, float ay,
                                          float bx, float by ) {
    float dx = bx-ax;
    float dy = by-ay;

    if ( Math.abs(dx) >= Math.abs(dy) )
      if ( dx > 0 ) {
        if ( ax > right ) return;
        drawLineSegment( g, ax,ay, right,dy/dx*(right-ax)+ay );
        }
      else {
        if ( ax < left ) return;
        drawLineSegment( g, ax,ay, left,dy/dx*(left-ax)+ay );
      }
    else if ( dy > 0 ) {
        if ( ay > upper ) return;
        drawLineSegment( g, ax,ay, dx/dy*(upper-ay)+ax,upper );
        }
      else {
        if ( ay < lower ) return;
        drawLineSegment( g, ax,ay, dx/dy*(lower-ay)+ax,lower );
      }
  }

}

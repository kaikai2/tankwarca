//----------------------------------------------------------------------------
//
// ajRecorder
//
// Aufnehmen/Abspielen von Ereignissen
// Laden/Speichern in Dateien
//
// 9.8.1996 PK
//
//----------------------------------------------------------------------------
//
// Die hier verwendeten Ereignisse gehen in ihrem Funktionsumfang ueber die
// "normalen" Events aus java.awt hinaus. Deshalb wird hier ein eigener
// Eventtyp ajEvent verwendet.
//
// ajRecorder zeichnet zunaechst alles im Hauptspeicher auf. Zusaetzlich gibt
// es Methoden, um die Eventliste in eine Datei abzuspeichern bzw. von dort
// in den Hauptspeicher zu laden.  Beim Einladen wird ein URL als Datei-
// bezeichner benutzt, da dies auch uebers Netz funktionieren soll.
// Das Abspeichern funktioniert schon wegen der SecurityManager-
// Beschraenkungen nur beim lokalen Aufrufen mit Appletviewer. Deshalb geht
// das mit einfachem String als Filenamen.
//
//----------------------------------------------------------------------------

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.Hashtable;

class ajEventReplay implements ajAnimation {
	long zero_t;
	private ajRecorder rec;

	ajEventReplay(ajRecorder rr) {
		zero_t = (new Date()).getTime();
		rec = rr;
		rec.reclist = rec.recorded[rec.selected_record];
	}

	public void do_it(long time) {
		while(rec.reclist != null && rec.reclist.timeStamp < time) {
			rec.postAjEvent(rec.reclist);
			rec.reclist = rec.reclist.nextEvent;
		}
		if(rec.reclist == null) {
			rec.remove(this);
		}
	}
}

public class ajRecorder extends ajAnimator {
	//
	// Datenstrukturen
	//

	VoronoiApplet va;

	ajFileLister lister;
	String recfilename = "Voronoi.ani";

	boolean SecurityAlert = false; // Wenn dieses #$%*-paranoide System wieder meckert.

	boolean fileAccess;  // Erlaubnis zum Abspeichern
	boolean save_op = false; // false: laden, true: speichern;

	StringBuffer selected = new StringBuffer();
	String directory;

	public long session_stamp;
	public long zero_t;
	public boolean record = false;
	public boolean replay = false;

	private ajEventReplay rep;

	public ajEvent[] recorded = new ajEvent[6];
	public long[] start_time = new long[6];
	public ajEvent reclist;

	public int selected_record;

	//
	// Konstruktor
	//

	public ajRecorder(VoronoiApplet app) {
		this(app, 30);
	}

	public ajRecorder(VoronoiApplet app, int t) {
		super(app, t);
		va = app;
		zero_t = 0;
		session_stamp = 0;
		selected_record = 0;

		URL cb = va.getCodeBase();
		String prot = cb.getProtocol();
		if(prot.compareTo("http") == 0 || prot.compareTo("HTTP") == 0) {
			System.out.println("Netbased applet. File storage disabled.");
			SecurityAlert = true;
		} else try {
			File f = new File(cb.getFile());
			String dir = f.getParent();
			f = new File(dir);
			if(f.isDirectory())
				SecurityAlert = false;
		} catch(SecurityException sec) {
			System.err.println("Security Manager restricts file operations. \n");
			SecurityAlert = true;
		} catch(NullPointerException nex) {};
	}

	//
	// Test auf vorhandene Aufnahme
	//

	public boolean hasRecord() {
		return(recorded[selected_record] != null);
	}

	//
	// Laden / Sichern
	//

	public void save_all(String filestub) {
		int tmp = selected_record;
		for(selected_record = 0; selected_record < 6; selected_record++) {
			if(hasRecord()) {
				save_record(filestub);
			}
		}
		selected_record = tmp;
	}

	public void save_record(String filestub) {
		String filename = filestub.concat(".").concat(String.valueOf(selected_record)).concat(".").concat(String.valueOf(start_time[selected_record])).concat(".ani");

		save_op = true;
		selected.setLength(0);
		selected.append(new File(va.getCodeBase().getFile()).getParent());
		selected.append(File.separator);
		selected.append(filename);
		load_save();
	}

	public void save(String fname) {
		DataOutputStream dos = null;

		if(replay) stop_replay();
		if(record) stop_recording();

		try {
			dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fname)));
		} catch(IOException ex) {
			System.out.println("FileOutputStream creation for " + fname + " failed.");
			return;
		} catch(NullPointerException nullex) {
			System.out.println("DataOutputStream creation for " + fname + " failed.");
			return;
		}

		try {
			dos.writeUTF("VANI");
		} catch(IOException e) {};

		ajEvent evt = recorded[selected_record];

		while(evt != null) {
			evt.write(dos);
			evt = evt.nextEvent;
		}

		try {
			dos.flush();
			dos.close();
		} catch(IOException e) {};
		dos = null;
	}

	public void load(URLConnection ucon) {
		DataInputStream din = null;

		//	System.out.println("URLConnection: " + ucon);
		if(record) stop_recording();
		if(replay) stop_replay();

		InputStream istr = null;
		try {
			istr = ucon.getInputStream();
		} catch(IOException ex) {
			System.out.println("Could not open URLConnection InputStream for " + ucon + ".");
			return;
		}

		BufferedInputStream bistr = null;
		try {
			bistr = new BufferedInputStream(istr);
		} catch(Exception ex) {
			System.out.println("BufferedInputStream creation failed on " + istr + ".");
			return;
		}

		try {
			din = new DataInputStream(bistr);
		} catch(Exception ex) {
			System.out.println("DataInputStream creation failed on " + bistr + ".");
			return;
		}

		String ident = null;

		try {
			ident = din.readUTF();
		} catch(IOException e) {
			System.out.println("Read failed on input stream");
		};

		if(ident == null || ident.compareTo("VANI") != 0) {
			System.out.println("File Format Ident string missing: " + ident + ".");
			try {
				din.close();
			} catch(IOException exc) {};
			din = null;
			return;
		}

		recorded[selected_record] = null;
		ajEvent rl = recorded[selected_record];
		ajEvent e = null;
		while((e = ajEvent.read(din)) != null) {
			if(rl == null) {
				recorded[selected_record] = e;
			} else {
				rl.nextEvent = e;
			}
			rl = e;
		}

		try {
			din.close();
		} catch(IOException exc) {};
		din = null;
	}

	//
	// Aufnahme / Wiedergabe
	//

	public void start_recording() {
		if(replay) stop_replay();
		Date d = new Date();
		zero_t = d.getTime();
		record = true;
		recorded[selected_record] = null;
		start_time[selected_record] = zero_t - session_stamp;
	}

	public void stop_recording() {
		if(!record) return;
		record = false;
	}

	public void start_replay() {
		if(record) stop_recording();

		record = false;
		replay = true;

		rep = new ajEventReplay(this);
		add(rep);
		start();
	}

	public void stop_replay() {
		if(!replay) return;

		replay = false;
		if(rep != null) {
			remove(rep);
		}
		rep = null;
		stop();
	}

	ajEvent rl = null;

	private void _recordEvent(ajEvent evt) {
		Date d = new Date();

		evt.timeStamp = d.getTime() - zero_t;
		if(recorded[selected_record] == null) {
			rl = evt;
			recorded[selected_record] = evt;
		} else {
			rl.nextEvent = evt;
		}
		rl = evt;
	}

	public void postAjEvent(ajEvent evt) {
		Event e = new Event(this, evt.timeStamp + zero_t, Event.ACTION_EVENT,
								  evt.arg1, evt.arg2, evt.arg3, evt.barg ? 1 : 0, evt);

		host.deliverEvent(e);
	}

	public void recordEvent(int what, ajPoint pt) {
		if(!record)
			return;
		ajEvent evt = new ajEvent(what);
		evt.arg1 = (int) pt.x;
		evt.arg2 = (int) pt.y;
		evt.arg3 = pt.ident;

		_recordEvent(evt);
	}

	public void recordEvent(int what, int arg1, int arg2) {
		if(!record)
			return;

		ajEvent evt = new ajEvent(what);
		evt.arg1 = arg1;
		evt.arg2 = arg2;

		_recordEvent(evt);
	}

	public void recordEvent(int what, int arg) {
		if(!record)
			return;

		ajEvent evt = new ajEvent(what);
		evt.arg1 = arg;

		_recordEvent(evt);
	}

	public void recordEvent(int what, boolean barg) {
		if(!record)
			return;

		ajEvent evt = new ajEvent(what);
		evt.barg = barg;

		_recordEvent(evt);
	}

	public void recordEvent(int what) {
		if(!record)
			return;

		_recordEvent(new ajEvent(what));
	}

	void do_load() {
		save_op = false;
		if(!SecurityAlert) {
			extensionFilter af;

			directory = System.getProperty("user.dir");
			af = new extensionFilter("ani");

			listerWaitThread lwt = new listerWaitThread(va);
			try {
				lister = new ajFileLister(".ani", lwt, selected, directory, af);
			} catch(IOException ioex) {};

			va.disable();
			lister.start();
			lwt.start();
		} else {
			selected.setLength(0);
			selected.append(new File(va.getCodeBase().getFile()).getParent());
			selected.append(File.separator);
			selected.append(recfilename);
			load_save();
		}
	}

	void do_save() {
		save_op = true;
		if(!SecurityAlert) {
			extensionFilter af;

			directory = System.getProperty("user.dir");
			af = new extensionFilter("ani");

			listerWaitThread lwt = new listerWaitThread(va);
			try {
				lister = new ajFileLister(".ani", lwt, selected, directory, af, true);
			} catch(IOException ioex) {};

			va.disable();
			lister.start();
			lwt.start();
		} else {
			selected.setLength(0);
			selected.append(new File(va.getCodeBase().getFile()).getParent());
			selected.append(File.separator);
			selected.append(recfilename);
			load_save();
		}
	}

	synchronized void load_save() {
		if(selected.length() == 0) return;
		stop_replay();
		stop_recording();
		if(save_op) {
//      System.out.println(selected);
			save(selected.toString());
		} else {
//			System.out.println(selected);
			URL codebase = va.getCodeBase();
			URL eventfile = null;
			try {
				eventfile = new URL(codebase, selected.toString());
			} catch(MalformedURLException e) {
				System.err.println("Malformed URL: " + selected.toString());
				selected.setLength(0);
			}
//System.out.println("URL: " + eventfile);
			URLConnection ucon = null;

			try {
				ucon = eventfile.openConnection();
			} catch(IOException e) {
				System.out.println("no URLConnection to file " + codebase.getProtocol() + codebase.getHost() + selected);
				selected.setLength(0);
			}

//			ucon.setDoOutput(true);
			ucon.setDoInput(true);

			load(ucon);

			if(hasRecord()) {
				va.recPanel.rec_loaded();
			} else {
				va.recPanel.no_rec_loaded();
			}
		}
		selected.setLength(0);
	}

	public void set_selected(int t) {
		if(t < recorded.length && t >= 0)
			selected_record = t;
//		System.out.println("selected: " + t);
	}

	public void inc_selected() {
		if(selected_record < recorded.length -1)
			selected_record++;
//		System.out.println("selected: " + t);
	}

//
// "session_stamp" soll den beginn einer AOF-Aufnahme-Sitzung enthalten.
// Damit koennen dann einzelne Aufnahmen mit einer passenden Zeitmarke
// automatisch in das Whiteboard-Objektfile eingepasst werden.
// (Feinjustierung muss natuerlich trotzdem noch erfolgen)
//
	public void set_session_stamp() {
		Date d = new Date();

		session_stamp = d.getTime();
	}
}

//----------------------------------------------------------------------------------------------------------
//
// ajRecorderPanel.java
//
// Kontrollpanel fuer Recorder-Funktionen
//
// PK 1996-10-21
//
//----------------------------------------------------------------------------------------------------------

import java.awt.*;
import java.net.*;
import java.util.*;

class ajRecorderPanel extends Panel {
	VoronoiApplet va;

	ajLed rec_led;
	ajButton record;
	ajButton play;
	ajButton stop;
	ajButton pause;

	ajButton load;
	ajButton save;

	Button firstrec, nextrec, stoprec;

	Checkbox slot0, slot1, slot2, slot3, slot4, slot5;
	Label recinfo;

	ajRecorderPanel(VoronoiApplet app, ajButtonImages img) {
		va = app;

		setLayout(new GridBagLayout());

		rec_led = new ajLed();

		rec_led.basecolor = Color.green;
		rec_led.duration = 400;
		rec_led.switch_off();

		record = new ajButton(ajButton.TOGGLE, img.recordOffImg, img.recordOnImg);
		stop = new ajButton(ajButton.PUSH, img.stopOffImg, img.stopOnImg);
		play = new ajButton(ajButton.TOGGLE, img.playOffImg, img.playOnImg);
		pause = new ajButton(ajButton.TOGGLE, img.pauseOffImg, img.pauseOnImg);

		load = new ajButton(ajButton.PUSH, img.loadOffImg, img.loadOnImg);
		save = new ajButton(ajButton.PUSH, img.saveOffImg, img.saveOnImg);

		firstrec = new Button("Erste Aufnahme");
		firstrec.setFont(new Font("Helvetica", Font.BOLD, 14));

		nextrec = new Button("N�chste Aufnahme");
		nextrec.setFont(new Font("Helvetica", Font.BOLD, 14));

		stoprec = new Button("Aufnahme beenden");
		stoprec.setFont(new Font("Helvetica", Font.BOLD, 14));

		recinfo = new Label("Aufnahme - von 6 (nicht aktiv)", Label.LEFT);
		recinfo.setFont(new Font("Helvetica", Font.BOLD, 14));

		Panel chp = new Panel();
		chp.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));

		CheckboxGroup slots = new CheckboxGroup();
		slot0 = new Checkbox("Slot #0", slots, true);
		slot1 = new Checkbox("Slot #1", slots, false);
		slot2 = new Checkbox("Slot #2", slots, false);
		slot3 = new Checkbox("Slot #3", slots, false);
		slot4 = new Checkbox("Slot #4", slots, false);
		slot5 = new Checkbox("Slot #5", slots, false);

		chp.add(slot0);
		chp.add(slot1);
		chp.add(slot2);
		chp.add(slot3);
		chp.add(slot4);
		chp.add(slot5);

		String aof = va.getParameter("AOFRecord");
		if(aof != null && aof.compareTo("true") == 0) {
			LayoutTools.gridBagConstrain(this, firstrec, 0, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);

			LayoutTools.gridBagConstrain(this, nextrec, 1, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);

			LayoutTools.gridBagConstrain(this, stoprec, 2, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);

			LayoutTools.gridBagConstrain(this, recinfo, 0, 2, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.WEST, 1.0, 0.0, 15, 15, 5, 5);

		} else {
			LayoutTools.gridBagConstrain(this, rec_led, 0, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);
			LayoutTools.gridBagConstrain(this, record, 1, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);
			LayoutTools.gridBagConstrain(this, play, 2, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
			LayoutTools.gridBagConstrain(this, pause, 3, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
			LayoutTools.gridBagConstrain(this, stop, 4, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
			LayoutTools.gridBagConstrain(this, load, 5, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);

			if(!va.evRec.SecurityAlert)
				LayoutTools.gridBagConstrain(this, save, 6, 1, 1, 1, GridBagConstraints.HORIZONTAL,
                        GridBagConstraints.WEST, 1.0, 0.0, 15, 5, 5, 5);

			LayoutTools.gridBagConstrain(this, chp, 0, 2, GridBagConstraints.REMAINDER, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);

		}

	}

	public boolean action(Event evt, Object obj) {
		if(evt.target == record) {
			va.do_record();
			return true;
		} else if(evt.target == stop || evt.target == stoprec) {
			va.do_stop();
			return true;
		} else if(evt.target == play) {
			va.do_replay();
			return true;
		} else if(evt.target == pause) {
			va.do_pause();
			return true;
		} else if(evt.target == firstrec) {
			va.do_stop();
			va.clear_canvas();
			slot_off(va.evRec.selected_record);
			va.evRec.selected_record = 0;
			slot_on(0);
			nextrec.enable();
			va.do_record();
			return true;
		} else if(evt.target == nextrec) {
			va.do_stop();
			va.clear_canvas();
			slot_off(va.evRec.selected_record);
			va.evRec.inc_selected();
			slot_on(va.evRec.selected_record);
			if(va.evRec.selected_record == 5)
				nextrec.disable();
			va.do_record();
			return true;
		} else if(evt.target == load) {
			postEvent(new Event(this, 0, Event.ACTION_EVENT, 0, 0, 1, 0));
			load.switch_off();
			return true;
		} else if(evt.target == save) {
			postEvent(new Event(this, 0, Event.ACTION_EVENT, 0, 0, 2, 0));
			save.switch_off();
			return true;
		} else if(evt.target == this && evt.key == 1) {
			va.evRec.do_load();
			return true;
		} else if(evt.target == this && evt.key == 2) {
			va.evRec.do_save();
			return true;
		} else if(evt.target == slot0) {
			va.evRec.set_selected(0);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		} else if(evt.target == slot1) {
			va.evRec.set_selected(1);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		} else if(evt.target == slot2) {
			va.evRec.set_selected(2);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		} else if(evt.target == slot3) {
			va.evRec.set_selected(3);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		} else if(evt.target == slot4) {
			va.evRec.set_selected(4);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		} else if(evt.target == slot5) {
			va.evRec.set_selected(5);
			if(va.evRec.recorded[va.evRec.selected_record] != null)
				rec_loaded();
			else
				no_rec_loaded();
			return true;
		}
//		System.out.println("Event: " + evt);
		return super.action(evt, obj);;
	}

	public void end_record() {
		record.switch_off();
		pause.switch_off();
		play.switch_off();
	}

	public void stop_rec() {
		end_record();
		recinfo.setText("Aufnahme - von 6 (nicht aktiv)");
		va.frame.demo.setState(false);
		load.enable();
		save.enable();
	}

	public void do_replay() {
		record.switch_off();
		pause.switch_off();
		play.switch_on();
		load.disable();
		save.disable();
	}

	public void do_record() {
		record.switch_on();
		pause.switch_off();
		play.switch_off();
		recinfo.setText("Aufnahme " + (va.evRec.selected_record + 1) + " von 6");
		load.disable();
		save.disable();
		repaint();
	}

	public void rec_loaded() {
		play.enable();
		save.enable();
		rec_led.switch_on();
		repaint();
	}

	public void no_rec_loaded() {
		save.disable();
		rec_led.switch_off();
		repaint();
	}

	public void clear_record() {
		save.disable();
		rec_led.switch_off();
		repaint();
	}

	public void slot_on(int i) {
		switch(i) {
			case 0:	slot0.setState(true);
						break;
			case 1:	slot1.setState(true);
						break;
			case 2:	slot2.setState(true);
						break;
			case 3:	slot3.setState(true);
						break;
			case 4:	slot4.setState(true);
						break;
			case 5:	slot5.setState(true);
						break;
		}
		if(va.evRec.recorded[va.evRec.selected_record] != null)
			rec_loaded();
		else
			no_rec_loaded();
	}

	public void slot_off(int i) {
		switch(i) {
			case 0:	slot0.setState(false);
						break;
			case 1:	slot1.setState(false);
						break;
			case 2:	slot2.setState(false);
						break;
			case 3:	slot3.setState(false);
						break;
			case 4:	slot4.setState(false);
						break;
			case 5:	slot5.setState(false);
						break;
		}
	}
}

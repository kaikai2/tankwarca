//---------------------------------------------------------------------------
//
// ajSegment.java
//
// Klasse f�r Liniensegmente
//
// LM 7.8.1996
//
//---------------------------------------------------------------------------



import java.awt.*;

public class ajSegment extends ajElement {

  ajPoint a,b;

// Anzeige als d�nne oder dicke Linien
  protected static boolean thinLines;

  public ajSegment() {
    color=segmentColor;
  }

  public ajSegment( ajPoint A, ajPoint B ) {
    a=A;
    b=B;
    color=segmentColor;
  }

  public ajSegment( ajPoint A, ajPoint B, Color col ) {
    a=A;
    b=B;
    color=col;
  }

  public String toString() {
    return(new String(" ajSg["+ a.toString() + "|" + b.toString() + "]"));
  }


// D�nne Linien ein/ausschalten
   public static void SetThinLines( boolean st ) {
      thinLines = st;
   }

  // Liniensegment malen

  public void draw( Graphics g ) {
    g.setColor(color);
    drawLineSegment(g,a,b);
  }

  public void draw( Graphics g, Color c ) {
    g.setColor(c);
    drawLineSegment(g,a,b);
  }

  public static void drawLineSegment( Graphics g, ajPoint a, ajPoint b ) {
    drawLineSegment( g, a.x,a.y, b.x,b.y );
  }

  // Liniensegment auf dem Bildschirm ausgeben, eigenes Clipping

  public static void drawLineSegment( Graphics g, float ax, float ay,
                                                  float bx, float by ) {
    float dx = bx-ax;
    float dy = by-ay;
                                          // Vereinfachtes Clipping
    if ( Math.abs(dx) >= Math.abs(dy) ) { // am senkrechten Streifen schneiden
      if ( ax < left ) {
        if ( bx < left ) return;
        ay = dy/dx*(left-ax)+ay;
        ax = left;
      }
      else if ( ax > right ) {
        if ( bx > right ) return;
        ay = dy/dx*(right-ax)+ay;
        ax = right;
      }
      if ( bx < left ) {
        by = dy/dx*(left-bx)+by;
        bx = left;
      }
      else if ( bx > right ) {
        by = dy/dx*(right-bx)+by;
        bx = right;
      }
      if ( (ay < lower && by < lower) || (ay > upper && by > upper) ) return;
    }
    else {                            // am waagerechten Streifen schneiden
      if ( ay < lower ) {
        if ( by < lower ) return;
        ax = dx/dy*(lower-ay)+ax;
        ay = lower;
      }
      else if ( ay > upper ) {
        if ( by > upper ) return;
        ax = dx/dy*(upper-ay)+ax;
        ay = upper;
      }
      if ( by < lower ) {
        bx = dx/dy*(lower-by)+bx;
        by = lower;
      }
      else if ( by > upper ) {
        bx = dx/dy*(upper-by)+bx;
        by = upper;
      }
      if ( (ax < left && bx < left) || (ax > right && bx > right) ) return;
    }

    if (ax < bx)
      g.drawLine( Math.round(ax), Math.round(ay),
                  Math.round(bx), Math.round(by) );
    else
      g.drawLine( Math.round(bx), Math.round(by),
                  Math.round(ax), Math.round(ay) );

    int AX=Math.round(ax);
    int AY=Math.round(ay);
    int BX=Math.round(bx);
    int BY=Math.round(by);

    if (AX < BX) {
        g.drawLine( AX,AY,BX,BY );
        if (! thinLines) {
            g.drawLine( AX+1,AY,BX+1,BY );
            g.drawLine( AX,AY+1,BX,BY+1 );
            g.drawLine( AX+1,AY+1,BX+1,BY+1 );
        }
    }
    else {
        g.drawLine( BX,BY,AX,AY );
        if (! thinLines) {
            g.drawLine( BX+1,BY,AX+1,AY );
            g.drawLine( BX,BY+1,AX,AY+1 );
            g.drawLine( BX+1,BY+1,AX+1,AY+1 );
        }
    }

  }


}

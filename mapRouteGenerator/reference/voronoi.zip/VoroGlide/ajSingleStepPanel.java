//----------------------------------------------------------------------------------------------------------
//
// ajSingleStepPanel
//
// Kapselung des Einzelschritt-Kommandopanels
//
// PK 1996-10-21
//
//----------------------------------------------------------------------------------------------------------

import java.awt.*;

class ajSingleStepPanel extends Panel {
	//
	// ajEvent.STEP subtypes
	//
	public final static int SM_STOP = 0;
	public final static int SM_BEGIN = 1;
	public final static int SM_ONE_BACK = 2;
	public final static int SM_AUTO = 3;
	public final static int SM_ONE = 4;
	public final static int SM_END = 5;
	public final static int SM_QUIT = 6;

	VoronoiApplet va;

	ajLed ez_led;
	ajButton stepBegin;
	ajButton stepEnd;
	ajButton stepOne;
	ajButton stepOneBack;
	ajButton stepPlay;
	ajButton stepStop;

	SpeedSlider slider;

	Button ez_ende;


	ajSingleStepPanel(VoronoiApplet app, ajButtonImages img) {
		va = app;

		setLayout(new GridBagLayout());

		stepBegin = new ajButton(ajButton.PUSH, img.anfangOffImg, img.anfangOnImg);
		stepEnd = new ajButton(ajButton.PUSH, img.endeOffImg, img.endeOnImg);
		stepOne = new ajButton(ajButton.PUSH, img.stepOffImg, img.stepOnImg);
		stepOneBack = new ajButton(ajButton.PUSH, img.stepBackOffImg, img.stepBackOnImg);
		stepPlay = new ajButton(ajButton.TOGGLE, img.playOffImg, img.playOnImg);
		stepStop = new ajButton(ajButton.PUSH, img.stopOffImg, img.stopOnImg);

		slider = new SpeedSlider(va, 250, 30, 100, 2000, 1000);
//    slider.enable(stepMode.getState());

		ez_ende = new Button("Ende");

		ez_led = new ajLed();

		ez_led.basecolor = Color.orange;
		ez_led.duration = 400;
		ez_led.switch_off();

		LayoutTools.gridBagConstrain(this, ez_led, 0, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);
		LayoutTools.gridBagConstrain(this, stepStop, 1, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 15, 5, 5);
		LayoutTools.gridBagConstrain(this, stepBegin, 2, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
		LayoutTools.gridBagConstrain(this, stepOneBack, 3, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
		LayoutTools.gridBagConstrain(this, stepPlay, 4, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
		LayoutTools.gridBagConstrain(this, stepOne, 5, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
		LayoutTools.gridBagConstrain(this, stepEnd, 6, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 15, 5, 5, 5);
		LayoutTools.gridBagConstrain(this, slider, 7, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.CENTER, 0.0, 0.0, 5, 20, 5, 20);
		LayoutTools.gridBagConstrain(this, ez_ende, 8, 1, 1, 1, GridBagConstraints.NONE,
                        GridBagConstraints.WEST, 1.0, 0.0, 15, 5, 5, 5);

	}

	public boolean action(Event evt, Object obj) {
		if(evt.target == va.evRec) {
			ajEvent aje = (ajEvent) evt.arg;
			mouseUpThread mut = null;
			Event nev = null;

			switch(aje.arg1) {
				case SM_STOP:
					nev = new Event(stepStop, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepStop.postEvent(nev);
					mut = new mouseUpThread(stepStop, evt.when, evt.x, evt.y, evt.modifiers);
					mut.start();
					return(true);
				case SM_BEGIN:
					nev = new Event(stepBegin, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepBegin.postEvent(nev);
					mut = new mouseUpThread(stepBegin, evt.when, evt.x, evt.y, evt.modifiers);
					mut.start();
					return(true);
				case SM_ONE_BACK:
					nev = new Event(stepOneBack, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepOneBack.postEvent(nev);
					mut = new mouseUpThread(stepOneBack, evt.when, evt.x, evt.y, evt.modifiers);
					mut.start();
					return(true);
				case SM_AUTO:
					nev = new Event(stepPlay, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepPlay.postEvent(nev);
					return(true);
				case SM_ONE:
					nev = new Event(stepOne, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepOne.postEvent(nev);
					mut = new mouseUpThread(stepOne, evt.when, evt.x, evt.y, evt.modifiers);
					mut.start();
					return(true);
				case SM_END:
					nev = new Event(stepEnd, evt.when, Event.MOUSE_DOWN,
										 evt.x, evt.y, 0, evt.modifiers);
					stepEnd.postEvent(nev);
					mut = new mouseUpThread(stepEnd, evt.when, evt.x, evt.y, evt.modifiers);
					mut.start();
					return(true);
				case SM_QUIT:
					evt.target = ez_ende;
					break;
				}
		} else if(evt.target == stepStop) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_STOP);
				va.stepper.stop_replay();
			}
			return true;
		} else if(evt.target == stepBegin) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_BEGIN);
				va.stepper.to_first();
			}
			return true;
		} else if(evt.target == stepOneBack) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_ONE_BACK);
				va.stepper.step_one_back();
			}
			return true;
		} else if(evt.target == stepPlay) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_AUTO);
				va.stepper.start_replay();
			}
			return true;
		} else if(evt.target == stepOne) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_ONE);
				va.stepper.single_step();
			}
			return true;
		} else if(evt.target == stepEnd) {
			if(va.stepping) {
				va.evRec.recordEvent(ajEvent.STEP, SM_END);
				va.stepper.to_last();
			}
			return true;
		}
		return super.action(evt, obj);
	}
}

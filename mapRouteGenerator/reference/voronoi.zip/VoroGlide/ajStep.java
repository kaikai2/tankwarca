//----------------------------------------------------------------------------
//
// ajStep
//
// Aufnehmen/Abspielen von Einzelschrittanzeige
//
// 11.9.1996 PK
//
//----------------------------------------------------------------------------

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.Date;
import java.util.Hashtable;

public class ajStep extends ajAnimator {
	//
	// Datenstrukturen
	//

	public long n;
	public long step_n;

	private ajStepElementReplay rep;
	private ajSingleStepPanel pan;

	public ajStepElement recorded = null;
	public ajStepElement step_pointer = null;

	ajCanvas canvas;

	//
	// Konstruktor
	//

	public ajStep(ajSingleStepPanel p, ajCanvas c) {
		super(c, 30);
		canvas = c;
		pan = p;

		n = 0;
		step_n = 0;
	}

	synchronized public void set_time(int t) {
		super.sleepTime = t;
	}

//
// Beginn der Animation von vorne
//
	public void begin() {
		to_first();
		start_replay();
	}

//
// zur�cksetzen nach Beendigung der Anzeige
//
	public void reset() {
		stop_replay();

		recorded = null;
		step_pointer = null;

		n = 0;
		step_n = 0;
	}

//
// Durchf�hren eines einzelnen Schrittes
//
	public synchronized void single_step() {
		//
		// wenn der step_pointer null ist, sind alle durchlaufen.
		//
		if(step_pointer == null) {
			Event e = new Event(this, Event.ACTION_EVENT, null);
			synchronized(canvas) {
				canvas.postEvent(e);
			}

			stop_replay();
			return;
		}

		while(step_pointer != null && step_pointer.timeStamp <= step_n) {
			synchronized(canvas) {
				switch(step_pointer.what) {
					case ajStepElement.ST_ADD:
						canvas.add(step_pointer.element, step_pointer.layer);
						break;
					case ajStepElement.ST_REMOVE:
						canvas.remove(step_pointer.element, step_pointer.layer);
						break;
				}
			}
			step_pointer = step_pointer.nextStepElement;
		}
		canvas.repaint();
		if(step_n < n)
			step_n++;
	}

	public void to_first() {
		stop_replay();
		canvas.cleanTempLayers();
		canvas.repaint();

		step_pointer = recorded;
		step_n = 0;
	}

	public void to_last() {
		to_first();

		while(step_pointer != null && step_pointer.timeStamp < n) {
			synchronized(canvas) {
				switch(step_pointer.what) {
					case ajStepElement.ST_ADD:
						canvas.add(step_pointer.element, step_pointer.layer);
						break;
					case ajStepElement.ST_REMOVE:
						canvas.remove(step_pointer.element, step_pointer.layer);
						break;
				}
			}
			step_pointer = step_pointer.nextStepElement;
		}
		canvas.paintTempLayers();
		step_n = n;
	}

	public void start_replay() {
		rep = new ajStepElementReplay(this);
		add(rep);
		pan.stepPlay.switch_on();
		start();
	}

	public void stop_replay() {
		stop();
		pan.stepPlay.switch_off();
		if(rep != null)
			remove(rep);
		rep = null;
	}

	public void step_one_back() {
		long pt = step_n;

		if(pt < 1) return;

		to_first();

		while(step_pointer != null && step_pointer.timeStamp < pt - 1) {
			synchronized(canvas) {
				switch(step_pointer.what) {
					case ajStepElement.ST_ADD:
						canvas.add(step_pointer.element, step_pointer.layer);
						break;
					case ajStepElement.ST_REMOVE:
						canvas.remove(step_pointer.element, step_pointer.layer);
						break;
				}
			}
			step_pointer = step_pointer.nextStepElement;
		}
		step_n = pt - 1;
		canvas.paintTempLayers();
	}

	public void add( ajElement obj, int layer ) {
		ajStepElement evt = new ajStepElement( n,obj,layer,ajStepElement.ST_ADD);

		if(recorded == null) {
			step_pointer = evt;
			recorded = evt;
		} else {
			step_pointer.nextStepElement = evt;
		}
		step_pointer = evt;
	}

  public void remove( ajElement obj, int layer ) {
    ajStepElement evt = new ajStepElement( n,obj,layer,ajStepElement.ST_REMOVE);

    if(recorded == null) {
      step_pointer = evt;
      recorded = evt;
    } else {
      step_pointer.nextStepElement = evt;
    }
    step_pointer = evt;
  }

// Liniensegment von a nach b hinzuf�gen
  public void add( ajPoint a, ajPoint b, int layer, Color col ) {
    add( new ajSegment(a,b,col),layer );
  }

// Element hinzuf�gen, Farbe wird gewechselt
  public void add( ajElement el, int layer, Color col ) {
    el.color = col;
    add( el,layer );
  }

// Punkt kopieren und in neuer Farbe hinzuf�gen,
// der Punkt kann sp�ter nicht mehr einzeln entfernt werden.
  public void add( ajPoint a, int layer, Color col ) {
    add( new ajPoint(a,col),layer );
  }

  public void pause() {
    n++;
  }

  public void pause(int m) {
    n += m;
  }
}

class ajStepElementReplay implements ajAnimation {
	private ajStep step;

	ajStepElementReplay(ajStep st) {
		step = st;
	}

	public void do_it(long time) {
		step.single_step();
	}
}

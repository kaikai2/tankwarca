//-----------------------------------------------------------------------
//
// ajStepElement
//
// Ereignisse zur Aufzeichnung von ANJA-Animationen
//
// PK 1996-08-26
//
//-----------------------------------------------------------------------

import java.io.*;

public class ajStepElement {
	public ajElement element;
	public int layer;
	int what;

	public final static int ST_ADD = 0;
	public final static int ST_REMOVE = 1;

	public long timeStamp;

	public ajStepElement nextStepElement;

	public ajStepElement(long t, ajElement obj, int l, int w) {
		timeStamp = t;
		element = obj;
		layer = l;
		what = w;
	}
}

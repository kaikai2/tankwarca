//---------------------------------------------------------------------------
//
// ajText.java
//
// Klasse fuer graphischen Text, abgeleitet aus ajElement
//
// PK 7.8.1996
//
//---------------------------------------------------------------------------

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public class ajText extends ajElement {
  //
  // Datenelemente
  //

  public int textSize = ajElement.textSize;
  public Font textFont = ajElement.textFont;

  public String str = "";
  public ajPoint p = null;        // Links unten

  //
  // Konstruktor
  //

  public ajText() {
  }

  public ajText(Color c) {
    super(c);
  }

  public ajText(Color c, boolean hide) {
    super(c, hide);
  }

  public ajText(String s) {
    str = s;
  }

  public ajText(String s, ajPoint px) {
    str = s;
    p = px;
  }

  public ajText(String s, Color c) {
    super(c);
    str = s;
  }

  public ajText(String s, Color c, boolean hide) {
    super(c, hide);
    str = s;
  }

  //
  // Methoden
  //

  public void draw(Graphics g, Color c) {
    g.setFont(textFont);
    g.setColor(c);
    g.drawString(str, (int) p.x, (int) p.y);
  }

  //
  // Zum verschieben des gesamten Objekts
  //

  public void move(float x, float y) {
    p.move(x, y);
  }
}

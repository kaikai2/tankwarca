//---------------------------------------------------------------------------
//
// ajTriangle.java
//
// Klasse f�r Dreiecke
//
// CI 8.8.1996
//
//---------------------------------------------------------------------------

import java.awt.*;

public class ajTriangle extends ajElement {

// Eckpunkte des Dreiecks
	ajPoint a,b,c;

// Nachbardreiecke
	ajTriangle abnext,bcnext,canext;

// Umkreis
	ajCircle circum;

// Flag f�r Halbebenen-Dreieck mit nur zwei Eckpunkten
	boolean halfplane=false;

// Besucherflag in jedem Dreieck
	boolean visitflag;

// Besucherflag Vergleichswert
	private static boolean visitValue=false;


// leerer Konstruktor
	public ajTriangle() {
		visitflag=visitValue;
	}


// Normale Konstruktoren
// Dreieck, Punkte gegen den Uhrzeigersinn geordnet,
// das Innere liegt also links von den Kanten.

	public ajTriangle( ajPoint A, ajPoint B, ajPoint C ) {

		visitflag=visitValue;
		a=A;
		int res = C.pointLineTest(A,B);
		if ( (res <= ajPoint.LEFT) ||
		     (res == ajPoint.INFRONTOFA) ||
		     (res == ajPoint.BEHINDB) ) {
			b=B;
			c=C;
		}
		else {  // RIGHT
			System.out.println("Warning, ajTriangle(A,B,C) "+
			"expects points in counterclockwise order.");
			System.out.println(""+A+B+C);
			b=C;
			c=B;
		}
		circumcircle();
	}

// besonderes "Dreieck", Halbebene durch zwei Punkte,
// das Innere der Halbebene liegt links von der Kante.

	public ajTriangle( ajPoint A, ajPoint B ) {

		visitflag=visitValue;
		a=A;
		b=B;
		halfplane=true;
	}


// point location in einer Triangulierung

// find findet das Dreieck, in dem p liegt, ausgehend vom Dreieck this.

	public ajTriangle find( ajPoint p ) {

		if ( p.pointLineTest(a,b) >= ajPoint.RIGHT )
			return abnext.findnext(p, this);
		if ( halfplane )
			return this;
		if ( p.pointLineTest(b,c) >= ajPoint.RIGHT )
			return bcnext.findnext(p, this);
		if ( p.pointLineTest(c,a) >= ajPoint.RIGHT )
			return canext.findnext(p, this);
		return this;
	}


// findnext findet das Dreieck, in dem p liegt, ausgehend vom Dreieck this,
// wobei feststeht, da� v ein Nachbardreieck von this ist, das
// p nicht enth�lt, weil p auf der Seite von this bez�glich
// der trennenden Kante v|this liegt.
// this und v k�nnen nicht beides Halbebenen sein.

  private ajTriangle findnext( ajPoint p, ajTriangle v ) {

    if ( halfplane )
      switch ( p.pointLineTest(a,b) ) {
        case ajPoint.LEFT:
        case ajPoint.ONSEGMENT:
          return this;
        case ajPoint.INFRONTOFA:
          return canext.findnext(p,this);
        case ajPoint.BEHINDB:
          return bcnext.findnext(p,this);
        case ajPoint.RIGHT:
          System.out.println( "Should not happen: point not in halfplane." );
          return abnext.findnext(p,this);
      }

    ajPoint p1,p2,p3;
    ajTriangle t1,t2;

    if ( abnext == v ) {
      p1=b; p2=c; p3=a;
      t1=bcnext; t2=canext;
    }
    else if ( bcnext == v ) {
      p1=c; p2=a; p3=b;
      t1=canext; t2=abnext;
    }
    else { // canext == v
      p1=a; p2=b; p3=c;
      t1=abnext; t2=bcnext;
    }
    if ( p.pointLineTest(p1,p2) >= ajPoint.RIGHT )
      return t1.findnext(p,this);
    if ( p.pointLineTest(p2,p3) >= ajPoint.RIGHT )
      return t2.findnext(p,this);
    return this;
  }


// Nachbarn auswechseln: this hat Nachbar Old und soll stattdessen
//                       Nachbar New haben.
  public void switchneighbors( ajTriangle Old,ajTriangle New ) {
    if ( abnext==Old ) abnext=New;
    else if ( bcnext==Old ) bcnext=New;
    else if ( canext==Old ) canext=New;
    else System.out.println( "Error, switchneighbors can't find Old." );
  }


// Nachbarn suchen: this hat Eckpunkt p und soll den Nachbarn zur�ckgeben,
// der an der Kante mit Endpunkt p im Gegenuhrzeigersinn liegt.
  public ajTriangle neighbor( ajPoint p ) {
    if ( a==p ) return canext;
    if ( b==p ) return abnext;
    if ( c==p ) return bcnext;
    System.out.println( "Error, neighbors can't find p: "+p );
    return null;
  }


// Umkreis eines Dreiecks (this) berechnen

  public ajCircle circumcircle() {

    float u = ((a.x-b.x)*(a.x+b.x) + (a.y-b.y)*(a.y+b.y)) / 2.0f;
    float v = ((b.x-c.x)*(b.x+c.x) + (b.y-c.y)*(b.y+c.y)) / 2.0f;
    float den = (a.x-b.x)*(b.y-c.y) - (b.x-c.x)*(a.y-b.y);
    if ( den==0 ) // oops, degenerate case
      circum = new ajCircle( a,Float.POSITIVE_INFINITY );
    else {
      ajPoint cen =  new ajPoint((u*(b.y-c.y) - v*(a.y-b.y)) / den,
                                 (v*(a.x-b.x) - u*(b.x-c.x)) / den);
      circum = new ajCircle( cen,cen.distance2(a) );
    }
    return circum;
  }


// Enth�lt der Umkreis eines Dreiecks (this) den Punkt p im Innern?

	public boolean circumcircle_contains( ajPoint p ) {

		return circum.r > circum.c.distance2(p);
	}


// Alle zusammenh�ngenden Dreiecke besuchen und die Kanten malen

  public void visitAndDraw( Graphics g ) {

    visitValue = !visitValue;
    visitMore(g);
  }

  private void visitMore( Graphics g ) {

    visitflag = visitValue;
    if ( abnext.visitflag != visitValue )
      ajSegment.drawLineSegment(g,a,b);
    if ( !halfplane ) {
      if ( bcnext.visitflag != visitValue )
        ajSegment.drawLineSegment(g,b,c);
      if ( canext.visitflag != visitValue )
        ajSegment.drawLineSegment(g,c,a);
    }
    if ( abnext.visitflag != visitValue )
      abnext.visitMore(g);
    if ( bcnext.visitflag != visitValue )
      bcnext.visitMore(g);
    if ( canext.visitflag != visitValue )
      canext.visitMore(g);    
  }


// Alle zusammenh�ngenden Dreiecke besuchen und die Umkreise
// auf System.out ausgeben

  public void visitAndPrint() {

    visitValue = !visitValue;
    visitMorePrint();
  }

  private void visitMorePrint() {

    visitflag = visitValue;
    if ( !halfplane ) {
		System.out.println(circum);
    }
    if ( abnext.visitflag != visitValue )
      abnext.visitMorePrint();
    if ( bcnext.visitflag != visitValue )
      bcnext.visitMorePrint();
    if ( canext.visitflag != visitValue )
      canext.visitMorePrint();    
  }


// Alle zusammenh�ngenden Dreiecke besuchen und die dualen Kanten malen

  public void visitAndDrawDual( Graphics g ) {

      visitValue = !visitValue;
      visitMoreDual(g);
  }

  private void visitMoreDual( Graphics g ) {

    visitflag = visitValue;
    if ( abnext.visitflag != visitValue )
        drawDualEdge(g,abnext);
    if (!halfplane ){
       if ( bcnext.visitflag != visitValue )           
           drawDualEdge(g,bcnext);
       if ( canext.visitflag != visitValue )
           drawDualEdge(g,canext);
     }
    if ( abnext.visitflag != visitValue )
           abnext.visitMoreDual(g);
    if ( bcnext.visitflag != visitValue )
        bcnext.visitMoreDual(g);
    if ( canext.visitflag != visitValue )
        canext.visitMoreDual(g);  
      
  }


// Alle zusammenh�ngenden Dreiecke besuchen und nur die H�lle malen

  public void visitAndDrawHull( Graphics g ) {

    ajTriangle tt = this;
    do {
      ajSegment.drawLineSegment(g,tt.a,tt.b);
      tt = tt.canext;
    } while ( tt != this );
  }


// duale Kante zwischen this und t

  public ajElement dualEdge( ajTriangle t ) {

    if ( t.halfplane )
      if ( halfplane ) {
        System.out.println("Warning, no dual edge between two halfplanes.");
        System.out.println(""+this+t);
        return null;
      }
      else
        return new ajRay(circum.c,
          new ajPoint( circum.c.x-(t.b.y-t.a.y),
                       circum.c.y+(t.b.x-t.a.x)
          )
        );
    else if ( halfplane )
      return new ajRay(t.circum.c,
        new ajPoint( t.circum.c.x-(b.y-a.y),
                     t.circum.c.y+(b.x-a.x)
        )
      );
    else
      return new ajSegment(circum.c,t.circum.c);
  }


// duale Kante malen zwischen this und t

  private void drawDualEdge( Graphics g, ajTriangle t ) {

    if ( t.halfplane )
      ajRay.drawRay(g,circum.c, circum.c.x-(t.b.y-t.a.y),
                                circum.c.y+(t.b.x-t.a.x));
    else if ( halfplane )
      ajRay.drawRay(g,t.circum.c, t.circum.c.x-(b.y-a.y),
                                  t.circum.c.y+(b.x-a.x));
    else
      ajSegment.drawLineSegment( g,circum.c,t.circum.c );
  }


// F�r Debugging etc.:

  public String toString() {

    String res;

    res = name(this)+a.toString()+b.toString();
    if ( !halfplane )
      res = res+c.toString();

    res=res+name(abnext)+name(bcnext)+name(canext);
    return res;
  }

  public static String name( ajTriangle t ) {

    if ( t == null )
      return " Tnull";
    return " T"+t.ident;
  }

}

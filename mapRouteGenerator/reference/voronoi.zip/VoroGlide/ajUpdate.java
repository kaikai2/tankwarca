import java.awt.Event;
import java.awt.Graphics;

public interface ajUpdate {
	public void ajUpdate(Graphics g);

   public boolean handleMouseDown(Event evt, int x, int y);
   public boolean handleMouseUp(Event evt, int x, int y);
   public boolean handleMouseDrag(Event evt, int x, int y);
   public boolean handleMouseEnter(Event evt, int x, int y);
   public boolean handleMouseExit(Event evt, int x, int y);
   public boolean handleMouseMove(Event evt, int x, int y);
   public boolean handleKeyDown(Event evt, int key);
   public boolean handleKeyUp(Event evt, int key);
}

//--------------------------------------------------------------------------------
//
// extensionFilter
//
// filtert fuer Directory-Listings die Files mit der richtigen Endung
// heraus.
//
// Angabe der Extension im Konstruktor OHNE Punkt! Der Punkt wird automatisch
// eingefuegt, um damit auch wirklich nur die Files zu bekommen, die auf
// .ext enden und nicht z.B. blahtext
//
// PK 1996-09-13
//
//--------------------------------------------------------------------------------

import java.io.*;

public class extensionFilter implements FilenameFilter {
	String extension;

	extensionFilter(String ext) {
		extension = "." + ext;
	}

	public boolean accept(File dir, String name) {
		if(name.endsWith(extension)) return true;
		else return new File(dir, name).isDirectory();
	}
}


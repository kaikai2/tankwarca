//
// listerWaitThread f�r VoronoiApplet
// 
// PK 1996-09-24
//

class listerWaitThread extends Thread {
  VoronoiApplet vapp;

  public listerWaitThread(VoronoiApplet va) {
    vapp = va;
  }

  public synchronized void run() {
    try {
      wait();
    } catch(InterruptedException ex) {};
    synchronized(vapp) {
      vapp.enable();
      vapp.evRec.load_save();
    }
    stop();
  }
}

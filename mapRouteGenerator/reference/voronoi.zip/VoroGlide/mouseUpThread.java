//
// mouseUpThread f�r VoronoiApplet
// 
// PK 1996-09-24
//

import java.awt.*;

class mouseUpThread extends Thread {
	Component comp;
	int x, y, mod;
	long when;

	public mouseUpThread(Component c, long ww, int xx, int yy, int mm) {
		comp = c;
		x = xx;
		y = yy;
		when = ww;
		mod = mm;
	}

	public synchronized void run() {
		try {
			sleep(300);
		} catch(InterruptedException ex) {};
		Event ev = new Event(comp, when + 300, Event.MOUSE_UP, x, y, 0, mod);
		comp.postEvent(ev);
	}
}

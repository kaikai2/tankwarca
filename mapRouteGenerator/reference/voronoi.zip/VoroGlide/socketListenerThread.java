//
// socketListenerThread f�r VoronoiApplet
//
// PK 1996-09-24
//

import java.awt.*;
import java.net.*;
import java.io.*;

class socketListenerThread extends Thread {
	VoronoiApplet vapp;
	Socket dsock;
	byte[] buffer;
	DataInputStream inStream;
	DataOutputStream outStream;
	static int fail_counter = 0;

	public int rcvPort = 12987;

	public socketListenerThread(VoronoiApplet va) {
		vapp = va;
		buffer = new byte[1024];
		try {
			dsock = new Socket(vapp.getCodeBase().getHost(), rcvPort);

			inStream = new DataInputStream(dsock.getInputStream());
			outStream = new DataOutputStream(dsock.getOutputStream());
		} catch(IOException ex) {
		} catch(NullPointerException nullex) {
			if(dsock == null)
				System.err.println("Could not connect to remote host");
		}
	}

	public synchronized void run() {
		for(;;) {
			String s = null;

			try {
				try {
					s = inStream.readUTF();
				} catch(IOException ex) {};
			} catch(NullPointerException nullex) {
				fail_counter++;
				if(fail_counter < 3) {
					new socketListenerThread(vapp).start();
					return;
				} else {
					System.err.println("Socket connection failed. Seems like VA_Server is not running on remote host.");
					return;
				}
			}

			if(!VA_Message.check_length(s)) {
				System.err.println("Message corrupted: " + s);
				continue;
			}

			String msg = VA_Message.get_message(s);

			String cmd = VA_Message.get_cmd(msg);

			if(cmd.compareTo("REGISTER") == 0) {
				System.out.println("VA_Server Registration #" + VA_Message.get_arg(msg));
			} else if(cmd.compareTo("START") == 0) {
				String arg = VA_Message.get_arg(msg);

				synchronized(vapp) {
					if(vapp.recPanel.load.isEnabled()) {
						vapp.evRec.save_op = false;

						vapp.evRec.selected.setLength(0);
						vapp.evRec.selected.append(new File(vapp.getCodeBase().getFile()).getParent());
						vapp.evRec.selected.append(File.separator);
						vapp.evRec.selected.append(arg);

						vapp.evRec.load_save();

						Event e = new Event(vapp.recPanel.play, Event.ACTION_EVENT, null);

						vapp.recPanel.postEvent(e);
					}
				}
			} else if(cmd.compareTo("LOAD") == 0) {
				String arg = VA_Message.get_arg(msg);

				synchronized(vapp) {
					if(vapp.recPanel.load.isEnabled()) {
						vapp.evRec.save_op = false;

						vapp.evRec.selected.setLength(0);
						vapp.evRec.selected.append(new File(vapp.getCodeBase().getFile()).getParent());
						vapp.evRec.selected.append(File.separator);
						vapp.evRec.selected.append(arg);

						vapp.evRec.load_save();

					}
				}
			} else if(cmd.compareTo("LOADSLOT") == 0) {
				String arg = VA_Message.get_arg(msg);
				String slotstr = VA_Message.get_cmd(arg);
				arg = VA_Message.get_arg(arg);

				int slot = Integer.parseInt(slotstr);

				synchronized(vapp) {
					int tmp = vapp.evRec.selected_record;
					vapp.recPanel.slot_off(vapp.evRec.selected_record);
					vapp.evRec.selected_record = slot;
					vapp.recPanel.slot_on(vapp.evRec.selected_record);

					if(vapp.recPanel.load.isEnabled()) {
						vapp.evRec.save_op = false;

						vapp.evRec.selected.setLength(0);
						vapp.evRec.selected.append(new File(vapp.getCodeBase().getFile()).getParent());
						vapp.evRec.selected.append(File.separator);
						vapp.evRec.selected.append(arg);

						vapp.evRec.load_save();

					}
					vapp.evRec.selected_record = tmp;
				}
			} else if(cmd.compareTo("SAVE") == 0) {
				String arg = VA_Message.get_arg(msg);

				synchronized(vapp) {
					if(vapp.recPanel.load.isEnabled()) {
						vapp.evRec.save_op = true;

						vapp.evRec.selected.setLength(0);
						vapp.evRec.selected.append(new File(vapp.getCodeBase().getFile()).getParent());
						vapp.evRec.selected.append(File.separator);
						vapp.evRec.selected.append(arg);

						vapp.evRec.load_save();

					}
				}
			} else if(cmd.compareTo("SAVEALL") == 0) {
				String arg = VA_Message.get_arg(msg);

				synchronized(vapp) {
					if(vapp.recPanel.load.isEnabled()) {
						vapp.evRec.save_all(arg);
					}
				}
			} else if(cmd.compareTo("STOP") == 0) {
				Event e = new Event(vapp.recPanel.stop, Event.ACTION_EVENT, null);

				vapp.recPanel.postEvent(e);
			} else if(cmd.compareTo("STAMP") == 0) {
				vapp.evRec.set_session_stamp();
			} else if(cmd.compareTo("PLAY") == 0) {
				Event e = new Event(vapp.recPanel.stop, Event.ACTION_EVENT, null);

				vapp.recPanel.postEvent(e);

				e = new Event(vapp.recPanel.play, Event.ACTION_EVENT, null);

				vapp.recPanel.deliverEvent(e);
			} else if(cmd.compareTo("PLAYSLOT") == 0) {
				String arg = VA_Message.get_arg(msg);

				int slot = Integer.parseInt(arg);

				vapp.recPanel.slot_off(vapp.evRec.selected_record);
				vapp.evRec.selected_record = slot;
				vapp.recPanel.slot_on(vapp.evRec.selected_record);

				Event e = new Event(vapp.recPanel.stop, Event.ACTION_EVENT, null);

				vapp.recPanel.postEvent(e);

				e = new Event(vapp.recPanel.play, Event.ACTION_EVENT, null);

				vapp.recPanel.deliverEvent(e);
			} else if(cmd.compareTo("CLEAR") == 0) {
				Event e = new Event(vapp.frame.clr, Event.ACTION_EVENT, null);

				vapp.frame.postEvent(e);
			} else if(cmd.compareTo("REC") == 0) {
				Event e = new Event(vapp.recPanel.record, Event.ACTION_EVENT, null);

				vapp.recPanel.deliverEvent(e);
			}
		}
	}

	public void finalize() {
		try {
			inStream.close();
			outStream.close();
			dsock.close();
		} catch(IOException ex) {};
	}
}
